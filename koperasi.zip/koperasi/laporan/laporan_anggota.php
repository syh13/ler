<?php 
	include "config/koneksi.php";
	include "fungsi/fungsi.php";

	$aksi=$_GET['aksi'];
	if(empty($aksi)){
?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-print"></i> Laporan Anggota</h1>

</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Daftar Data Anggota</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Kode Anggota</th>
						<th>Nama</th>
						<th>TTL</th>
						<th>Alamat</th>
						<th>Kelamin</th>
						<th>Pekerjaan</th>
						<th>Tanggal Masuk</th>
						<th>Status</th>
						<th>Telepon</th>
					</tr>		
				</thead>
				<tbody>
					<?php
						$query = mysql_query("SELECT * FROM t_anggota ORDER BY kode_anggota");
						$no=1;while($data=mysql_fetch_array($query)){
					?>
					<tr align="center">
						<td><?php echo $no;?></td>
						<td><?php echo $data['kode_anggota'];?></td>
						<td align="left"><?php echo $data['nama_anggota'];?></td>
						<td><?php echo $data['tempat_lahir'];?>, <?php echo $data['tgl_lahir'];?></td>
						<td><?php echo $data['alamat_anggota'];?></td>
						<td><?php echo $data['jenis_kelamin'];?></td>
						<td><?php echo $data['pekerjaan'];?></td>
						<td><?php echo $data['tgl_masuk'];?></td>
						<td>
							<?php
							if ($data['status']=='aktif'){
								echo "<span class='badge badge-success'>Aktif</span>";
							} else {
								echo "<span class='badge badge-danger'>Keluar</span>";
							}
							?>
						</td>
						<td><?php echo $data['telp'];?></td>
					</tr> 
					<?php
						$no++;}
					?>
				</tbody> 
			</table>
		</div>
	</div>
</div>
<?php
}
?>
