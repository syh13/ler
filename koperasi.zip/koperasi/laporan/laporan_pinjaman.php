<?php 
	include "config/koneksi.php";
	include "config/fungsi.php";

	$aksi=$_GET['aksi'];
	if(empty($aksi)){}
	else if($aksi=='semua')
	{
?>


<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-print"></i> Laporan Pinjaman</h1>

    <a href="laporan/print_pinjaman.php" class="btn btn-primary"> <i class="fa fa-print"></i> Cetak Data </a>
</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Daftar Data Pinjaman</h6>
    </div>

    <div class="card-body">
		<ul class="nav nav-tabs nav-justified mb-3">
			<li class="nav-item">
				<a class="nav-item nav-link active" href="?pilih=lapdatapinjam&aksi=semua">Semua</a>
			</li>
			<li class="nav-item">
				<a class="nav-item nav-link text-success" href="?pilih=lapdatapinjam&aksi=jatuhtempo">Jatuh Tempo</a>
			</li>
			<li class="nav-item">
				<a class="nav-item nav-link text-success" href="?pilih=lapdatapinjam&aksi=telat">Telat</a>
			</li>
		</ul>
		
		<div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Kode Pinjam</th>
						<th>Nama Anggota</th>
						<th>Tangggal Pinjam</th>
						<th>Tangggal Tempo</th>
						<th>Jenis Pinjam</th>
						<th>Besar Pinjam</th>
						<th>Lama Angsuran</th>
						<th>Status</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<tbody>
					<?php $sql=mysql_query("SELECT * from t_pinjam order by kode_pinjam desc");
						$nomer=1;
						while($data=mysql_fetch_array($sql)){
						$kd_a=$data['kode_anggota'];
						$anggota=mysql_fetch_array(mysql_query("SELECT nama_anggota from t_anggota where kode_anggota='$kd_a'"));
						$kd_j=$data['kode_jenis_pinjam'];
						$jenis=mysql_fetch_array(mysql_query("SELECT nama_pinjaman from t_jenis_pinjam where kode_jenis_pinjam='$kd_j'"));
					?>
					<tr align="center">
						<td><?php echo $nomer;?></td>
						<td><?php echo $kd_p=$data['kode_pinjam'];?></td>
						<td><?php echo $anggota['nama_anggota'];?></td>
						<td><?php echo $data['tgl_entri'];?></td>
						<td><?php echo $data['tgl_tempo'];?></td>
						<td><?php echo $jenis['nama_pinjaman'];?></td>
						<td>Rp. <?php echo number_format($data['besar_pinjam']);?></td>
						<td><?php echo $data['lama_angsuran'];?> Bulan</td>
						<td>
							<?php
								$jum=mysql_num_rows(mysql_query("SELECT*from t_angsur where kode_pinjam='$kd_p' and kode_anggota='$kd_a'"));$lama=mysql_fetch_array(mysql_query("SELECT lama_angsuran from t_pinjam where kode_pinjam='$kd_p' and kode_anggota='$kd_a'"));
								if($jum==$lama['lama_angsuran']){
									echo '<span class="badge badge-success">Lunas</span>';
								}else{
									echo '<span class="badge badge-danger">Belum Lunas</span>';
								}
							?>
						</td>
						<td align="center">
							<a data-toggle="tooltip" data-placement="bottom" title="Detail Data" href="?pilih=lapdatapinjam&aksi=show&kode_anggota=<?php echo $data['kode_anggota'];?>&kode_pinjam=<?php echo $data['kode_pinjam'];?>" class="btn btn-success btn-sm"><i class="fa fa-eye"></i></a>
						</td>
					</tr>
						<?php
						$nomer++;
						}
						?> 
				</tbody>   
			</table>
		</div>
	</div>
</div>

<?php 
	}elseif($aksi=='show'){
	$kode=$_GET['kode_anggota'];
	$kode_pinjam=$_GET['kode_pinjam'];
	$q=mysql_query("SELECT*from t_angsur where kode_pinjam='$kode_pinjam' AND kode_anggota='$kode' order by kode_angsur desc");
	
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-print"></i> Laporan Data Pinjaman</h1>

	<div>
		<a href="laporan/print_angsuran.php?kode_pinjam=<?php echo $kode_pinjam;?>&kode_anggota=<?php echo $kode; ?>" class="btn btn-primary"> <i class="fa fa-print"></i> Cetak Data </a>
		
		<a href="?pilih=lapdatapinjam&aksi=semua" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
		<span class="text">Kembali</span>
	</a>
	</div>
</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Daftar Data Riwayat Angsuran <?php $angg=mysql_fetch_array(mysql_query("SELECT nama_anggota from t_anggota where kode_anggota='$kode'")); echo $angg['nama_anggota'];?></h6>
    </div>

    <div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Kode Angsuran</th>
						<th>Kode Pinjam</th>
						<th>Tanggal Angsuran</th>
						<th>Angsuran Ke</th>
						<th>Besar Angsuran</th>
						<th>Denda</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$no=1;
						while($ang=mysql_fetch_array($q)){
					?>
					<tr align="center">
						<td><?php echo $no;?></td>
						<td><?php echo $ang['kode_angsur'];?></td>
						<td><?php echo $l=$ang['kode_pinjam'];?></td>
						<td><?php echo $ang['tgl_entri'];?></td>
						<td><?php echo $ang['angsuran_ke'];?></td>
						<td>Rp. <?php echo Rp($ang['besar_angsuran']);?></td>
						<td>Rp. <?php echo Rp($ang['denda']);?></td>
					</tr>
					<?php
						$no++;}
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>

<?php
}else if($aksi=='telat'){
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-print"></i> Laporan Data Pinjaman</h1>

    <a href="laporan/print_telat.php" class="btn btn-primary"> <i class="fa fa-print"></i> Cetak Data </a>
</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Daftar Data Pinjaman</h6>
    </div>

    <div class="card-body">
		<ul class="nav nav-tabs nav-justified mb-3">
			<li class="nav-item">
				<a class="nav-item nav-link text-success" href="?pilih=lapdatapinjam&aksi=semua">Semua</a>
			</li>
			<li class="nav-item">
				<a class="nav-item nav-link text-success" href="?pilih=lapdatapinjam&aksi=jatuhtempo">Jatuh Tempo</a>
			</li>
			<li class="nav-item">
				<a class="nav-item nav-link active" href="?pilih=lapdatapinjam&aksi=telat">Telat</a>
			</li>
		</ul>
		
		<div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Kode Pinjam</th>
						<th>Nama Anggota</th>
						<th>Tangggal Pinjam</th>
						<th>Tangggal Tempo</th>
						<th>Telat</th>
						<th>Denda</th>
						<th>Status</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$sql=mysql_query("SELECT * from t_pinjam where status='belum lunas' order by kode_pinjam desc");
						$nomer=1;
						while($data=mysql_fetch_array($sql)){
							$a=$data['tgl_tempo'];$dat=date("Y-m-d");
							if($dat>$a){
								$go=round($telat=((abs(strtotime($dat)-strtotime($a)))/(60*60*24))); $denda=$go * 1000;
								$kd_a=$data['kode_anggota'];
								$anggota=mysql_fetch_array(mysql_query("SELECT nama_anggota from t_anggota where kode_anggota='$kd_a'"));
								$kd_j=$data['kode_jenis_pinjam'];
								$jenis=mysql_fetch_array(mysql_query("SELECT nama_pinjaman from t_jenis_pinjam where kode_jenis_pinjam='$kd_j'"));
					?>
					<tr align="center">
						<td><?php echo $nomer;?></td>
						<td><?php echo $kd_p=$data['kode_pinjam'];?></td>
						<td><?php echo $anggota['nama_anggota'];?></td>
						<td><?php echo $data['tgl_entri'];?></td>
						<td><?php echo $a;?></td>
						<td><?php echo $go;?> Hari</td>
						<td>Rp. <?php echo number_format($denda);?></td>
						<td>
							<?php
								$jum=mysql_num_rows(mysql_query("SELECT*from t_angsur where kode_pinjam='$kd_p' and kode_anggota='$kd_a'"));$lama=mysql_fetch_array(mysql_query("SELECT lama_angsuran from t_pinjam where kode_pinjam='$kd_p' and kode_anggota='$kd_a'"));
								if($jum==$lama['lama_angsuran']){
									echo '<span class="badge badge-success">Lunas</span>';
								}else{
									echo '<span class="badge badge-danger">Belum Lunas</span>';
								}
							?>
						</td>
						<td align="center">
							<a data-toggle="tooltip" data-placement="bottom" title="Detail Data" href="?pilih=lapdatapinjam&aksi=show&kode_anggota=<?php echo $data['kode_anggota'];?>&kode_pinjam=<?php echo $data['kode_pinjam'];?>" class="btn btn-success btn-sm"><i class="fa fa-eye"></i></a>
						</td>
					</tr>
						<?php
						}else{}
						$nomer++;
						}
						?> 
				</tbody>   
			</table>
		</div>
	</div>
</div>

<?php 
}else if($aksi=='jatuhtempo'){
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-print"></i> Laporan Data Pinjaman</h1>

    <a href="laporan/print_jatuh_tempo.php" class="btn btn-primary"> <i class="fa fa-print"></i> Cetak Data </a>
</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Daftar Data Pinjaman</h6>
    </div>

    <div class="card-body">
		<ul class="nav nav-tabs nav-justified mb-3">
			<li class="nav-item">
				<a class="nav-item nav-link text-success" href="?pilih=lapdatapinjam&aksi=semua">Semua</a>
			</li>
			<li class="nav-item">
				<a class="nav-item nav-link active" href="?pilih=lapdatapinjam&aksi=jatuhtempo">Jatuh Tempo</a>
			</li>
			<li class="nav-item">
				<a class="nav-item nav-link text-success" href="?pilih=lapdatapinjam&aksi=telat">Telat</a>
			</li>
		</ul>
		
		<div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Kode Pinjam</th>
						<th>Nama Anggota</th>
						<th>Tangggal Pinjam</th>
						<th>Tangggal Tempo</th>
						<th>Besar Pinjam</th>
						<th>Lama Angsuran</th>
						<th>Status</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$sql=mysql_query("SELECT * from t_pinjam where status='belum lunas'");
						$nomer=1;
						while($data=mysql_fetch_array($sql)){
							$a=$data['tgl_tempo'];$dat=date("Y-m-d");
							if($a==$dat){
								$kd_a=$data['kode_anggota'];
								$anggota=mysql_fetch_array(mysql_query("SELECT nama_anggota from t_anggota where kode_anggota='$kd_a'"));
								$kd_j=$data['kode_jenis_pinjam'];
								$jenis=mysql_fetch_array(mysql_query("SELECT nama_pinjaman from t_jenis_pinjam where kode_jenis_pinjam='$kd_j'"));
					?>
					<tr align="center">
						<td><?php echo $nomer;?></td>
						<td><?php echo $kd_p=$data['kode_pinjam'];?></td>
						<td><?php echo $anggota['nama_anggota'];?></td>
						<td><?php echo $data['tgl_entri'];?></td>
						<td><?php echo $a;?></td>
						<td>Rp. <?php echo number_format($data['besar_pinjam']);?></td>
						<td><?php echo $data['lama_angsuran'];?> Bulan</td>
						<td>
							<?php
								$jum=mysql_num_rows(mysql_query("SELECT*from t_angsur where kode_pinjam='$kd_p' and kode_anggota='$kd_a'"));$lama=mysql_fetch_array(mysql_query("SELECT lama_angsuran from t_pinjam where kode_pinjam='$kd_p' and kode_anggota='$kd_a'"));
								if($jum==$lama['lama_angsuran']){
									echo '<span class="badge badge-success">Lunas</span>';
								}else{
									echo '<span class="badge badge-danger">Belum Lunas</span>';
								}
							?>
						</td>
						<td align="center">
							<a data-toggle="tooltip" data-placement="bottom" title="Detail Data" href="?pilih=lapdatapinjam&aksi=show&kode_anggota=<?php echo $data['kode_anggota'];?>&kode_pinjam=<?php echo $data['kode_pinjam'];?>" class="btn btn-success btn-sm"><i class="fa fa-eye"></i></a>
						</td>
					</tr>
						<?php
						}else{}
						$nomer++;
						}
						?> 
				</tbody>   
			</table>
		</div>
	</div>
</div>
<?php 
}
?>