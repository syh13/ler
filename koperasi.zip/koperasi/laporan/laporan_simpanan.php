<?php 
	include "config/koneksi.php";
	include "config/fungsi.php";

	$aksi=$_GET['aksi'];
	if(empty($aksi)){
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-print"></i> Laporan Simpanan</h1>

    <a href="laporan/print_simpanan.php" class="btn btn-primary"> <i class="fa fa-print"></i> Cetak Data </a>
</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Daftar Data Simpanan</h6>
    </div>

    <div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Nama</th>
						<th>Pokok</th>	
						<th>Wajib</th>	
						<th>Sukarela</th>	
						<th>Total Simpanan</th>	
						<th>Aksi</th>					
					</tr>
				</thead>
				<tbody>
					<?php
						$query = mysql_query("SELECT * from t_anggota");
						$no=1;	
						while($data=mysql_fetch_array($query)){
						$kode_ang=$data['kode_anggota'];
					?>
					<tr align="right">
						<td align="center"><?php echo $no?></td>
						<td align="left"><?php echo $data['nama_anggota'];?></td>
						<?php $d=mysql_fetch_array(mysql_query("SELECT SUM(besar_simpanan) as pokok from t_simpan where kode_anggota='$kode_ang' and jenis_simpan='pokok'")); ?>
						<td>Rp. <?php echo number_format($d['pokok']);?></td>
						<?php $e=mysql_fetch_array(mysql_query("SELECT SUM(besar_simpanan) as wajib from t_simpan where kode_anggota='$kode_ang' and jenis_simpan='wajib'")); ?>
						<td>Rp. <?php echo number_format($e['wajib']);?></td>
						<?php $f=mysql_fetch_array(mysql_query("SELECT SUM(besar_simpanan) as sukarela from t_simpan where kode_anggota='$kode_ang' and jenis_simpan='sukarela'")); ?>
						<td>Rp. <?php echo number_format($f['sukarela']);?></td>
						<?php $total=$d['pokok']+$e['wajib']+$f['sukarela']; ?>
						<td>Rp. <?php echo number_format($total);?></td>
						<td align="center">
							<a data-toggle="tooltip" data-placement="bottom" title="Detail Data" href="?pilih=lapdatasimpanan&aksi=show&kode_anggota=<?php echo $data['kode_anggota'];?>" class="btn btn-success btn-sm"><i class="fa fa-eye"></i></a>
						</tr>
					<?php
						$no++;}
					?>
				</tbody>  
			</table>
		</div>
	</div>
</div>
	
<?php
	}elseif($aksi=='show'){
	$kode=$_GET['kode_anggota'];
	$q=mysql_query("SELECT S.*, A.nama_anggota FROM t_simpan S, t_anggota A
					WHERE S.kode_anggota = A.kode_anggota AND S.kode_anggota = '$kode'");
	$ang=mysql_fetch_array($q);
?>


<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-print"></i> Laporan Data Simpanan</h1>

	<div>
		<a href="laporan/print_simpanan.php" class="btn btn-primary"> <i class="fa fa-print"></i> Cetak Data </a>
		
		<a href="?pilih=lapdatasimpanan" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
		<span class="text">Kembali</span>
	</a>
	</div>
</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Daftar Data Simpanan <?php echo $ang['nama_anggota'];?></h6>
    </div>

    <div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Tanggal Simpan</th>
						<th>Nama Simpanan</th>
						<th>Besar Simpanan</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$query = mysql_query("SELECT * from t_simpan where kode_anggota='$kode'");
						echo '';	
						$no=1;
						while($data=mysql_fetch_array($query)){
					?>
					<tr align="center">
						<td><?php echo $no;?></td>
						<td><?php echo Tgl($data['tgl_entri']);?></td>
						<td><?php echo $data['jenis_simpan'];?></td>
						<td>Rp. <?php echo Rp($data['besar_simpanan']);?></td>
					</tr> 
					<?php
						$no++;}
					?>
				</tbody>   
			</table>
		</div>
		<div class="alert alert-info mt-3">
			Total Saldo Tabungan <?php echo $ang['nama_anggota'];?> Adalah <b>Rp. <?php $bu=mysql_fetch_array(mysql_query("SELECT sum(besar_simpanan) as besar_simpan from t_simpan where kode_anggota='$kode'")); echo number_format($bu['besar_simpan']);?></b>
		</div>
	</div>
</div>
<?php
}
?>