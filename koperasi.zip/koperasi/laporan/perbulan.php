<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-print"></i> Laporan Perbulan</h1>
</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Pilih Bulan & Tahun</h6>
    </div>

    <div class="card-body">
		<form action="laporan/print_perbulan.php" method="post">
			<div class="row">
				<div class="form-group col-md-5">
					<select class="form-control" name="bulan" required>
						<option value="">--Pilih Bulan--</option>
						<option value="01">Januari</option>
						<option value="02">Februari</option>
						<option value="03">Maret</option>
						<option value="04">April</option>
						<option value="05">Mei</option>
						<option value="06">Juni</option>
						<option value="07">Juli</option>
						<option value="08">Agustus</option>
						<option value="09">September</option>
						<option value="10">Oktober</option>
						<option value="11">November</option>
						<option value="12">Desember</option>               
					</select>
				</div>
				
				<div class="form-group col-md-5">
					<input autocomplete="off" type="number" name="tahun" required class="form-control" placeholder="Tahun" />
				</div>
				
				<div class="form-group col-md-2">
					<button type="submit" class="btn btn-primary w-100"><i class="fa fa-print"></i> Cetak Data</button>
				</div>
			</div>
		</form>
	</div>
</div>