<?php 
	include "../config/koneksi.php";
	$aksi=$_GET['aksi'];
	if(empty($aksi)){
		$kodeaa=$_SESSION['kopid'];
?>
<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Simpanan</h6>
	</div>
    <div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Tanggal Simpan</a></th>
						<th>Nama Simpanan</a></th>
						<th>Besar Simpanan</a></th>
					</tr>
				</thead>
				<tbody>
				<?php
					$kode=$_SESSION['kopid'];
					$query=mysql_query("SELECT * FROM t_simpan WHERE kode_simpan=$kode");
					$no=1;
					while($data=mysql_fetch_array($sqlku)){
				?>
					<tr align="center">
						<td><?php echo $no?></td>
						<td><?php echo Tgl($data['tgl_entri']);?></td>
						<td><?php echo $data['jenis_simpan'];?></td>
						<td align="right">Rp. <?php echo Rp($data['besar_simpanan']);?></td>
					</tr> 
					<?php
						$no++;}
					?>
				</tbody>   
			</table>
		</div>
		<div class="alert alert-info mt-3">
		Total Saldo Simpanan Adalah <b>Rp. <?php $bu=mysql_fetch_array(mysql_query("SELECT sum(besar_simpanan) as besar_simpan from t_simpan where kode_anggota='$kode'")); echo Rp($bu['besar_simpan']);?></b>
		</div>
	</div>
</div>
<?php
}
?>