<?php 
	include "../config/koneksi.php";
	$aksi=$_GET['aksi'];
	if(empty($aksi)){
		$kodeaa=$_SESSION['kopid'];
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-location-arrow"></i> Pengajuan Pinjaman</h1>
	<?php
		$verida=mysql_fetch_array(mysql_query("SELECT tp.*,ti.status as status_p FROM t_pengajuan tp, t_pinjam ti where tp.kode_anggota='$kodeaa' ORDER BY kode_pengajuan desc"));
		$num=mysql_num_rows($verida);
		if($verida['status']=='diterima'&$verida['status_p']=='belum lunas') {
			echo '<a href="?pilih=datapengajuan&aksi=tambah" class="btn btn-secondary disabled"> <i class="fa fa-plus"></i> Ajukan Pinjaman </a>';
		}else if($verida['status']=='menunggu') {
			echo '<a href="?pilih=datapengajuan&aksi=tambah" class="btn btn-secondary disabled"> <i class="fa fa-plus"></i> Ajukan Pinjaman </a>';
		}else if($verida['status']=='ditolak') {
			echo '<a href="?pilih=datapengajuan&aksi=tambah" class="btn btn-success"> <i class="fa fa-plus"></i> Ajukan Pinjaman </a>';
		}else if($num<=0) {
			echo '<a href="?pilih=datapengajuan&aksi=tambah" class="btn btn-success"> <i class="fa fa-plus"></i> Ajukan Pinjaman </a>';
		}else if($verida['status_p']=='belum lunas') {
			echo '<a href="?pilih=datapengajuan&aksi=tambah" class="btn btn-secondary disabled"> <i class="fa fa-plus"></i> Ajukan Pinjaman </a>';
		}else if($verida['status_p']=='lunas') {
			echo '<a href="?pilih=datapengajuan&aksi=tambah" class="btn btn-success"> <i class="fa fa-plus"></i> Ajukan Pinjaman </a>';
		}
	?>
</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Pengajuan Pinjaman</h6>
    </div>
	<div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Tanggal Pengajuan</th>
						<th>Besar Pinjam</th>
						<th>Lama Angsur</th>
						<th>Jenis Pinjam</th>
						<th>Besar Angsuran</th>
						<th>Status</th>
						<th>Tanggal Terima</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<tbody>
				<?php		
					$kode= $_SESSION['kopid'];
					$sqlku=mysql_query("SELECT * from t_pengajuan where kode_anggota='$kode' order by tgl_pengajuan desc");
					$no=1;
					while($data=mysql_fetch_array($sqlku)){
				?>
					<tr align="center">
						<td><?php echo $no;?></td>
						<td><?php echo $data['tgl_pengajuan'];?></td>
						<td><?php echo number_format($data['besar_pinjam']);?></td>
						<?php
							$rr=$data['kode_jenis_pinjam'];
							$oo=mysql_fetch_array(mysql_query("SELECT*from t_jenis_pinjam where kode_jenis_pinjam='$rr'"));
						?>
						<td><?php echo $oo['lama_angsuran'];?> Bulan</td>
						<?php
							$asli=$data['besar_pinjam']/$oo['lama_angsuran'];
							$bung=$oo['bunga']/100;
							$bunganya=$data['besar_pinjam']*$bung;
							$total=$asli+$bunganya;
						?>
						<td><?php echo $oo['nama_pinjaman'];?></td>
						<td><?php echo number_format($total);?></td>
						<td>
							<?php if($data['status']=='diterima'){
								echo "<span class='badge badge-success'>Diterima</span>";
							} else if($data['status']=='ditolak'){
								echo "<span class='badge badge-danger'>Ditolak</span>";
							} else{
								echo "<span class='badge badge-info'>Menunggu</span>";
							}
							?>
						</td>
						<td>
							<?php if($data['status']=='diterima'){
								echo $data['tgl_acc'];
							} else {
								echo "Tanggal Tidak Tersedia";
							}
							?>
						</td>
						<?php
							if(($data['status']=='menunggu')||($data['status']=='ditolak')){
						?>
						<td>
							<a data-toggle="tooltip" data-placement="bottom" title="Cetak Data" href="#" class="btn btn-primary btn-sm disabled"><i class="fa fa-print"></i></a>
						</td>
						<?php } ?>
						<?php if($data['status']=='diterima')
						{?>
						<td>
							<a data-toggle="tooltip" data-placement="bottom" title="Cetak Data" href="print_pengajuan.php?kode_pengajuan=<?php echo $data['kode_pengajuan'];?>&sesion=<?php echo $_SESSION['kopname'];?>" class="btn btn-primary btn-sm"><i class="fa fa-print"></i></a>
						</td>
						<?php } ?>
						
						
					</tr> 
					<?php
						$no++;} //tutup while
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Riwayat Angsuran</h6>
    </div>
	<div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Besar Pinjam</th>
						<th>Besar Angsuran</th>
						<th>Lama Angsuran</th>
						<th>Angsuran Ke-</th>
						<th>Tanggal Tempo</th>
						<th>Status</th>
					</tr>
				</thead>
				<tbody>
				<?php		
					$kode= $_SESSION['kopid'];
					$sqlku=mysql_query("SELECT * FROM t_pinjam WHERE kode_anggota=$kode");
					$no=1;
					while($data=mysql_fetch_array($sqlku)){
				?>
					<tr align="center">
						<td><?php echo $no;?></td>
						<td><?php echo number_format($data['besar_pinjam']);?></td>
						<td><?php echo number_format($data['besar_angsuran']);?></td>
						<td><?php echo $data['lama_angsuran'];?></td>
						<td><?php echo $data['sisa_angsuran'];?></td>
						<td><?php echo $data['tgl_tempo'];?></td>
						<td><?php echo $data['status'];?></td>
					</tr> 
					<?php
						$no++;} //tutup while
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php
	}else if($aksi=='tambah'){
		$kodeaa=$_SESSION['kopid'];
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-location-arrow"></i> Pengajuan Pinjaman</h1>
	<a href="?pilih=datapengajuan" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
		<span class="text">Kembali</span>
	</a>	
</div>
<?php 
		$datastatus = mysql_fetch_array(mysql_query,"SELECT * FROM t_pinjam WHERE status = 'belum lunas'");

		while($fetch=mysql_fetch_array($datastatus)){
	?>
	<div class="alert alert-danger">
		<button type="button" class="close" data-dismiss="alert">&times;</button>
    	<strong>Mohon Maaf!!!</strong> Diharapkan menyelesaikan dahulu angsuran anda sebelumnya.
	</div>
	<?php 
		}
	?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fas fa-fw fa-plus"></i> Pengajuan Pinjaman <?php include "config/koneksi.php"; $dfl=mysql_fetch_array(mysql_query("SELECT * from t_anggota where kode_anggota='$kodeaa'")); echo $dfl['nama_anggota']; ?></h6>
	</div>
	<form action="proses_pengajuan.php?proses=tambah" method="post">
		<div class="card-body">
			<?php 
			$kdp=mysql_fetch_array(mysql_query("SELECT kode_pengajuan from t_pengajuan order by kode_pengajuan desc"));
			$kode=$kdp['kode_pengajuan']+1;
			?>
			<div class="row">
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Kode Pengajuan</label>
					<input autocomplete="off" type="text" name="kode_pengajuan" value="<?php echo $kode;?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Tanggal Pengajuan</label>
					<input autocomplete="off" type="date" name="tgl_pengajuan" value="<?php echo date("Y-m-d");?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Kode Anggota</label>
					<input autocomplete="off" type="text" name="kode_anggota" value="<?php echo $kodeaa;?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Jenis Pinjaman</label>
					<select name="kode_jenis_pinjam" class="form-control">
						<option value="">--Pilih Jenis Pinjaman--</option>
						<?php
						$q=mysql_query("SELECT * FROM t_jenis_pinjam");
						while($a=mysql_fetch_array($q)){
						?>
						<option value="<?php echo $a['kode_jenis_pinjam'];?>"><?php echo $a['nama_pinjaman'];?> /Maks : <?php echo $a['maks_pinjam'];?> /Bunga : <?php echo $a['bunga'];?>% /Lama : <?php echo $a['lama_angsuran'];?> Bulan</option>
						<?php
						}
						?>
					</select>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Besar Pinjaman</label>
					<input autocomplete="off" type="text" name="besar_pinjam" required class="form-control"/>
				</div>
			</div>
		</div>
		<div class="card-footer text-right">
            <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Ajukan</button>
            <button type="reset" class="btn btn-info"><i class="fa fa-sync-alt"></i> Reset</button>
        </div>
	</form>
</div>

<?php
}
?>
