<div class="mb-4">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-home"></i> Dashboard</h1>
    </div>
    <!-- Content Row -->
    <?php
		include "../config/koneksi.php";
		$kode= $_SESSION['kopid'];
		$query=mysql_query("SELECT * FROM t_anggota WHERE kode_anggota='$kode'");
		$data=mysql_fetch_array($query);
		if ($data['password']) {
	?>
	<div class="alert alert-danger">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
		Password anda masih default. Silahkan ganti terlebih dahulu password anda agar akun anda tertap aman. Ganti password anda pada menu <a class="btn btn-danger btn-sm" href="?pilih=profile">Profile</a>
	</div>
	<?php
	}
	?>
	<div class="alert alert-success">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        Selamat datang <span class="text-uppercase"><b><?php echo $_SESSION['kopname']; ?>!</b></span> Anda bisa mengoperasikan sistem dengan wewenang tertentu melalui pilihan menu di bawah.
    </div>
    <div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h3 class="m-0 font-weight-bold text-success"><i class="fa fa-box"></i>Peraturan</h3>
    </div>
    <div class="card-body">
        <h5>1. Jaminan harus lebih besar dari plafon kredit.</h5>
        <h5>2. Untuk kendaraan bermotor mengkuti harga pasar.</h5>
        <h5>3. Konsumen wajib membayar angsuran menurut perjanjian masing-masing.</h5>
        <h5>4. Konsumen wajib berdomisili plosogenuk.</h5>
        <h5>5. Tipe angsuran terdiri dari bulanan dan musiman (bulanan dan 6 bulan musiman).</h5>
        <h5>6. Apabila perpanjangan, jumlah pinjaman wajib lebih besar dari sebelumnya.</h5>
        <h5>7. Konsumen wajib memberikan keterangan secara tertulis penghasilan dan pengeluaran.</h5>
        <h5>8. Sanksi keterlambatan :</h5>
            <div class="mx-auto" style="width: 1000px;">
                <h5>a. Teguran tertulis</h5>
                <h5>b. Pemasangan banner ukuran 1x1 yang dipasang didepan rumah konsumen ( 3 x pembayaran tertunggak) biaya pasang banner dibebankan ke konsumen</h5>
                <h5>c. Untuk jaminan bergerak kendaraan R4/R2 akan dilakukan  pengamanan jaminan 4 pembayaran tertunggak</h5>
            </div>
        <h5>9. Untuk jaminan kendaran wajib nama BPKB/STNK wajib dalam 1 kartu kartu keluarga yang tercatat di catatan sipil.</h5>
        <h5>10. Pendekatan persuasif akan dilakukan terlebih dahulu sebelum sanksi no 8.</h5>
        <h5>11. Pelunasan sebelum jatuh tempo, maka jasa pelunasan akan dikenakan 1 kali.</h5>
        <h5>12. Wajib mengisi formulir yang disediakan pihak "BUMDesa".</h5>
        <h5>13. Tidak ada 2 nama dalam satu angsuran.</h5>
        <h5>14. Apabila perpanjangan,wajib lunas dulu pinjaman pertama.</h5>
    </div>
    <div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i>Plafon BUMDes</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Kode</a></th>
						<th>Jenis Pinjaman</th>
						<th>Pokok</th>
						<th>Jasa/Bulan</th>
						<th>Tenor</th>
						<th>Jasa/Tahun</th>
						<th>Pokok Bulanan</th>
						<th>Jasa</th>
						<th>Angsuran</th>
						<th>Pembulatan</th>
					</tr>
				</thead>
                <tbody>
                <?php	
                $kode= $_SESSION['kopid'];
                $sqlku=mysql_query("SELECT * from plafon_bumdes");
                $no=1;
                while($data=mysql_fetch_array($sqlku)){
                ?>
					<tr align="center">
						<td><?php echo $no;?></td>
						<td><?php echo $data['kode_plafon'];?></td>
						<td><?php echo $data['jenis_pinjaman'];?></td>
						<td><?php echo $data['pokok'];?></td>
						<td><?php echo $data['jasa_bln'];?></td>
						<td><?php echo $data['tenor'];?></td>
						<td><?php echo $data['jasa_thn'];?></td>
						<td><?php echo $data['pokok_bln'];?></td>
						<td><?php echo $data['jasa'];?></td>
						<td><?php echo $data['angsuran'];?></td>
						<td><?php echo $data['pembulatan'];?></td>
					</tr> 
				<?php
				$no++;}
				?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>