<?php
include "../config/koneksi.php";
$proses=$_GET['proses'];
if($proses=='tambah')
{
	$kode_pengajuan=$_POST['kode_pengajuan'];
	$tgl_pengajuan=$_POST['tgl_pengajuan'];
	$kode_anggota=$_POST['kode_anggota'];
	$kode_jenis=$_POST['kode_jenis_pinjam'];
	$besar_pinjam=$_POST['besar_pinjam'];
	$polo=mysql_fetch_array(mysql_query("SELECT * from t_jenis_pinjam where kode_jenis_pinjam='$kode_jenis' "));
	$hasil=$polo['maks_pinjam'];
	if($besar_pinjam>$hasil)
	{ ?>
	<script>
			alert("Besar Pinjaman Melebihi Maksimal Pinjam");
			window.location="index.php?pilih=datapengajuan&aksi=tambah";
	</script>
	<?php }
	else
	{
	$sql=mysql_query("INSERT into t_pengajuan values('$kode_pengajuan','$tgl_pengajuan','$kode_anggota','$kode_jenis','$besar_pinjam','','menunggu')");
	if($sql)
	{
		header("location:index.php?pilih=datapengajuan");
	}
	else
	{
		echo 'gagal';
	}
}
	
}
?>