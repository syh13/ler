<?php 
	include "../config/koneksi.php";
	
	$kode= $_SESSION['kopid'];
	$qubah=mysql_query("SELECT * FROM t_anggota WHERE kode_anggota='$kode'");
	$data2=mysql_fetch_array($qubah);
?>


<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-cogs"></i> Data Profile</h1>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fas fa-fw fa-edit"></i> Edit Data Profile</h6>
    </div>
	
	<form action="edit_profile.php" method="get" enctype="multipart/form-data">
		<div class="card-body">
			<div class="row">
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Kode Anggota</label>
					<input autocomplete="off" type="text" name="kode_anggota" value="<?php echo $data2['kode_anggota'];?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Password</label>
					<input autocomplete="off" type="text" name="password" value="<?php echo $data2['password'];?>" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Nama Lengkap</label>
					<input autocomplete="off" type="text" name="nama_anggota" required value="<?php echo $data2['nama_anggota'];?>" class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Jenis Kelamin</label>
					<select name="jenis_kelamin" class="form-control" required>
						<option value="">--Pilih Jenis Kelamin--</optiom>
						<option value="Laki-laki" <?php if ($data2['jenis_kelamin'] == "Laki-laki"){echo "selected";}?>>Laki-laki</optiom>
						<option value="Perempuan" <?php if ($data2['jenis_kelamin'] == "Perempuan"){echo "selected";}?>>Perempuan</optiom>
					</select>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Tempat Lahir</label>
					<input autocomplete="off" type="text" name="tmp_lahir" required value="<?php echo $data2['tempat_lahir'];?>" class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Tanggal Lahir</label>
					<input autocomplete="off" type="date" name="tgl_lahir" required value="<?php echo $data2['tgl_lahir'];?>" class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Telp</label>
					<input autocomplete="off" type="text" name="telp" required value="<?php echo $data2['telp'];?>" class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Pekerjaan</label>
					<input autocomplete="off" type="text" name="pekerjaan" required value="<?php echo $data2['pekerjaan'];?>" class="form-control"/>
				</div>
				
				<div class="form-group col-md-12">
					<label class="font-weight-bold">Alamat</label>
					<textarea name="alamat_anggota" required class="form-control"><?php echo $data2['alamat_anggota'];?></textarea>
				</div>
				
				<input autocomplete="off" type="hidden" name="tgl_entri" value="<?php echo date("Y-m-d");?>" required class="form-control" readonly="readonly"/>
				<input autocomplete="off" type="hidden" name="tgl_masuk" value="<?php echo $data2['tgl_masuk'];?>" required class="form-control"/>
			
			</div>
		</div>
	
		<div class="card-footer text-right">
            <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Update</button>
            <button type="reset" class="btn btn-info"><i class="fa fa-sync-alt"></i> Reset</button>
        </div>
	</form>
</div>