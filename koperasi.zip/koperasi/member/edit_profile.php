<?php
include '../config/koneksi.php';
$kode=$_GET['kode_anggota'];
$tanggal_masuk=$_GET['tgl_masuk'];
$password=$_GET['password'];
$nama=$_GET['nama_anggota'];
$jk=$_GET['jenis_kelamin'];
$tgllahir=$_GET['tgl_lahir'];
$tmplahir=$_GET['tmp_lahir'];
$alamat=$_GET['alamat_anggota'];
$tlp=$_GET['telp'];
$kerja=$_GET['pekerjaan'];
$entri=$_GET['tgl_entri'];
$sql=mysql_query("UPDATE t_anggota SET kode_anggota='$kode', password='$password',nama_anggota='$nama',alamat_anggota='$alamat',jenis_kelamin='$jk',pekerjaan='$kerja',tgl_masuk='$tanggal_masuk',telp='$tlp',tempat_lahir='$tmplahir',tgl_lahir='$tgllahir',tgl_entri='$entri' WHERE kode_anggota='$kode'");
if($sql)
{
?>
	<script>alert("Edit Profile Berhasil!");window.location="../member/index.php?pilih=profile";</script>
<?php
}
else
{
?>
	<script>alert("Gagal Edit Profile!");window.location="../member/index.php?pilih=profile";</script>
<?php
}
?>