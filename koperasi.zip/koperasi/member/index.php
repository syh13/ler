<?php
	session_start();
	if(empty($_SESSION['kopname'])||empty($_SESSION['kopid'])){
?>
	<script>
	window.location="../login/login.php"; 
	</script>
<?php
	}else {
	include "header.php";
		if(@$_GET['pilih'] == 'home'){
			include ("home.php");
		}else if(@$_GET['pilih'] == 'datapengajuan'){
			include"pengajuan.php";
		}else if(@$_GET['pilih'] == 'datasimpanan'){
			include"simpanan.php";
		} else if(@$_GET['pilih'] == 'profile'){
			include"profile.php";
		} else {
			include"home.php";
		}
	include "footer.php";
	}
?>