<?php
	session_start();
	if(empty($_SESSION['kopname'])||empty($_SESSION['level'])){
?>
	<script>
	window.location="login/login.php"; 
	</script>
<?php
	}else {
	include "header.php";
		if(@$_GET['pilih'] == 'home'){
			include ("home.php");
		}
		else if(@$_GET['pilih'] == 'dataanggota'){
			include"anggota/mst_anggota.php";
		}
		else if(@$_GET['pilih'] == 'datatabungan'){
			include"anggota/mst_tabungan.php";
		}
		else if(@$_GET['pilih'] == 'datatransaksi'){
			include"transaksi/transaksi.php";
		}
		else if(@$_GET['pilih'] == 'lapdataanggota'){
			include"laporan/laporan_anggota.php";
		}
		else if(@$_GET['pilih'] == 'lapdatasimpanan'){
			include"laporan/laporan_simpanan.php";
		}
		else if(@$_GET['pilih'] == 'lapdatapinjam'){
			include"laporan/laporan_pinjaman.php";
		}
		else if(@$_GET['pilih'] == 'datajenissimpanan'){
			include"setting/setting_simpanan.php";
		}
		else if(@$_GET['pilih'] == 'datajenispinjaman'){
			include"setting/setting_pinjaman.php";
		}
		else if(@$_GET['pilih'] == 'datajenisplafon'){
			include"setting/setting_plafon.php";
		}
		else if(@$_GET['pilih'] == 'datapengguna'){
			include"setting/setting_user.php";
		}
		else if(@$_GET['pilih'] == 'datapengajuan'){
			include"pengajuan/pengajuan.php";
		}
		else if(@$_GET['pilih'] == 'lapperbulan'){
			include"laporan/perbulan.php";
		} else {
			include"home.php";
		}
	include "footer.php";
	}
?>