<?php  
	include "config/koneksi.php";
	include "config/fungsi.php";

	$aksi=$_GET['aksi'];
?>


<?php
	if(empty($aksi)){
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-cogs"></i> Data Jenis Pinjaman</h1>

	<a href="?pilih=datajenispinjaman&aksi=tambah" class="btn btn-success"> <i class="fa fa-plus"></i> Tambah Data </a>
</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Daftar Data Jenis Pinjaman</h6>
    </div>

    <div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Jenis Pinjaman</th>
						<th>Lama Angsur</th>
						<th>Maksimal Pinjam</th>
						<th>Bunga (%)</th>
						<th>Tanggal Entri</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$no=1;
						$sql=mysql_query("SELECT * FROM t_jenis_pinjam");
						while($data=mysql_fetch_array($sql)){
					?>
					<tr align="center">
						<td><?php echo $no;?></td>
						<td><?php echo $data['nama_pinjaman'];?></td>
						<td><?php echo $data['lama_angsuran'];?> Bulan</td>
						<td>Rp. <?php echo Rp($data['maks_pinjam']);?></td>
						<td><?php echo $data['bunga'];?>%</td>
						<td><?php echo Tgl($data['tgl_entri']);?></td>
						<td>
							<div class="btn-group" role="group">
								<a data-toggle="tooltip" data-placement="bottom" title="Edit Data" href="?pilih=datajenispinjaman&aksi=ubah&kode_jenis_pinjam=<?php echo $data['kode_jenis_pinjam'];?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a>
								
								<a data-toggle="tooltip" data-placement="bottom" title="Hapus Data" href="setting/proses_setting_pinjam.php?pros=hapus&kode_jenis_pinjam=<?php echo $data['kode_jenis_pinjam'];?>" onclick="return confirm ('Apakah anda yakin untuk meghapus data ini')" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
							</div>
						</td>
					</tr>   
					<?php
						$no++;
						}
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>

<?php
	}elseif($aksi=='tambah'){
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-cogs"></i> Data Jenis Pinjaman</h1>

	<a href="?pilih=datajenispinjaman" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
		<span class="text">Kembali</span>
	</a>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fas fa-fw fa-plus"></i> Tambah Data Jenis Pinjaman</h6>
    </div>
	
	<form action="setting/proses_setting_pinjam.php?pros=tambah" method="post">
		<div class="card-body">
			<div class="row">
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Kode Pinjaman</label>
					<input autocomplete="off" type="text" name="kode_jenis_pinjam" value="<?php echo nomer("P","kode_jenis_pinjam","t_jenis_pinjam");?>" readonly required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Jenis Pinjaman</label>
					<input autocomplete="off" type="text" name="nama_pinjaman" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Lama Angsur (Bulan)</label>
					<input autocomplete="off" type="number" name="lama_angsuran" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Maksimal Pinjam</label>
					<input autocomplete="off" type="number" name="maks_pinjam" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Bunga (%)</label>
					<input autocomplete="off" type="text" name="bunga" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">User Entri</label>
					<input autocomplete="off" type="text" name="u_entry" value="<?php session_start(); echo $_SESSION['kopname'];?>" readonly required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Tanggal Entri</label>
					<input autocomplete="off" type="text" name="tgl_entri" value="<?php echo date("Y-m-d");?>" readonly required class="form-control"/>
				</div>
			</div>
		</div>
		<div class="card-footer text-right">
            <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
            <button type="reset" class="btn btn-info"><i class="fa fa-sync-alt"></i> Reset</button>
        </div>
	</form>
</div>

<?php
	}elseif($aksi=='ubah'){
		$kode=$_GET['kode_jenis_pinjam'];
		$q=mysql_query("SELECT * FROM t_jenis_pinjam WHERE kode_jenis_pinjam='$kode'");
		$data2=mysql_fetch_array($q);
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-cogs"></i> Data Jenis Pinjaman</h1>

	<a href="?pilih=datajenispinjaman" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
		<span class="text">Kembali</span>
	</a>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fas fa-fw fa-edit"></i> Edit Data Jenis Pinjaman</h6>
    </div>
	
	<form action="setting/proses_setting_pinjam.php?pros=ubah" method="post">
		<div class="card-body">
			<div class="row">
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Kode Pinjaman</label>
					<input autocomplete="off" type="text" name="kode_jenis_pinjam" value="<?php echo $data2['kode_jenis_pinjam'];?>" readonly required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Jenis Pinjaman</label>
					<input autocomplete="off" type="text" name="nama_pinjaman" value="<?php echo $data2['nama_pinjaman'];?>" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Lama Angsur (Bulan)</label>
					<input autocomplete="off" type="number" name="lama_angsuran" value="<?php echo $data2['lama_angsuran'];?>" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Maksimal Pinjam</label>
					<input autocomplete="off" type="number" name="maks_pinjam" value="<?php echo $data2['maks_pinjam'];?>" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Bunga (%)</label>
					<input autocomplete="off" type="number" name="bunga" value="<?php echo $data2['bunga'];?>" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Tanggal Entri</label>
					<input autocomplete="off" type="text" name="tgl_entri" value="<?php echo $data2['tgl_entri'];?>" readonly required class="form-control"/>
				</div>
			</div>
		</div>
		<div class="card-footer text-right">
            <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Update</button>
            <button type="reset" class="btn btn-info"><i class="fa fa-sync-alt"></i> Reset</button>
        </div>
	</form>
</div>

<?php
}
?>

