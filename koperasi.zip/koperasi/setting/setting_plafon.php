<?php  
	include "config/koneksi.php";
	include "config/fungsi.php";

	$aksi=$_GET['aksi'];
?>


<?php
	if(empty($aksi)){
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-cogs"></i> Data Jenis Pinjaman</h1>

	<a href="?pilih=datajenisplafon&aksi=tambah" class="btn btn-success"> <i class="fa fa-plus"></i> Tambah Data </a>
</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Daftar Data Jenis Pinjaman</h6>
    </div>

    <div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Kode</a></th>
						<th>Jenis Plafon</a></th>
						<th>Pokok</th>
						<th>Jasa (Bulan)</th>
						<th>Tenor</th>
						<th>Jasa (Tahun)</th>
						<th>Pokok Bulanan</th>
						<th>Jasa</th>
						<th>Angsuran</th>
						<th>Pembulatan</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$no=1;
						$sql=mysql_query("SELECT * FROM plafon_bumdes");
						while($data=mysql_fetch_array($sql)){
					?>
					<tr align="center">
					<td><?php echo $no;?></td>
						<td><?php echo $data['kode_plafon'];?></td>
						<td><?php echo $data['jenis_pinjaman'];?></td>
						<td><?php echo $data['pokok'];?></td>
						<td><?php echo $data['jasa_bln'];?></td>
						<td><?php echo $data['tenor'];?></td>
						<td><?php echo $data['jasa_thn'];?></td>
						<td><?php echo $data['pokok_bln'];?></td>
						<td><?php echo $data['jasa'];?></td>
						<td><?php echo $data['angsuran'];?></td>
						<td><?php echo $data['pembulatan'];?></td>
						<td>
							<div class="btn-group" role="group">
								<a data-toggle="tooltip" data-placement="bottom" title="Edit Data" href="?pilih=datajenispinjaman&aksi=ubah&kode_plafon=<?php echo $data['kode_plafon'];?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a>
								
								<a data-toggle="tooltip" data-placement="bottom" title="Hapus Data" href="setting/proses_setting_plafon.php?pros=hapus&kode_plafon=<?php echo $data['kode_plafon'];?>" onclick="return confirm ('Apakah anda yakin untuk meghapus data ini')" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
							</div>
						</td>
					</tr>   
					<?php
						$no++;
						}
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>

<?php
	}elseif($aksi=='tambah'){
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-cogs"></i> Data Jenis Pinjaman</h1>

	<a href="?pilih=datajenisplafon" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
		<span class="text">Kembali</span>
	</a>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fas fa-fw fa-plus"></i> Tambah Data Jenis Pinjaman</h6>
    </div>
	
	<form action="setting/proses_setting_plafon.php?pros=tambah" method="post">
		<div class="card-body">
			<div class="row">
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Kode Plafon</label>
					<input autocomplete="off" type="text" name="kode_plafon" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Jenis Plafon</label>
					<input autocomplete="off" type="text" name="jenis_pinjaman" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Pokok</label>
					<input autocomplete="off" type="text" name="pokok" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Jasa (Bulan)</label>
					<input autocomplete="off" type="text" name="jasa_bln" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Tenor</label>
					<input autocomplete="off" type="text" name="tenor" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Jasa (Tahun)</label>
					<input autocomplete="off" type="text" name="jasa_thn" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Pokok (Bulan)</label>
					<input autocomplete="off" type="text" name="pokok_bln" required class="form-control"/>
				</div>

				<div class="form-group col-md-6">
					<label class="font-weight-bold">Jasa</label>
					<input autocomplete="off" type="text" name="jasa" required class="form-control"/>
				</div>

				<div class="form-group col-md-6">
					<label class="font-weight-bold">Angsuran</label>
					<input autocomplete="off" type="text" name="angsuran" required class="form-control"/>
				</div>

				<div class="form-group col-md-6">
					<label class="font-weight-bold">Pembulatan</label>
					<input autocomplete="off" type="text" name="pembulatan" required class="form-control"/>
				</div>
			</div>
		</div>
		<div class="card-footer text-right">
            <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
            <button type="reset" class="btn btn-info"><i class="fa fa-sync-alt"></i> Reset</button>
        </div>
	</form>
</div>

<?php
	}elseif($aksi=='ubah'){
		$kode=$_GET['kode_plafon'];
		$q=mysql_query("SELECT * FROM plafon_bumdes WHERE kode_plafon='$kode'");
		$data2=mysql_fetch_array($q);
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-cogs"></i> Data Jenis Pinjaman</h1>

	<a href="?pilih=datajenispinjaman" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
		<span class="text">Kembali</span>
	</a>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fas fa-fw fa-edit"></i> Edit Data Jenis Pinjaman</h6>
    </div>
	
	<form action="setting/proses_setting_plafon.php?pros=ubah" method="post">
		<div class="card-body">
			<div class="row">
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Kode</label>
					<input autocomplete="off" type="text" name="kode_plafon" value="<?php echo $data2['kode_plafon'];?>" readonly required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Jenis Pinjaman</label>
					<input autocomplete="off" type="text" name="jenis_pinjaman" value="<?php echo $data2['jenis_pinjaman'];?>" required class="form-control"/>
				</div>

				<div class="form-group col-md-6">
					<label class="font-weight-bold">Pokok</label>
					<input autocomplete="off" type="text" name="pokok" value="<?php echo $data2['pokok'];?>" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Jasa (Bulan)</label>
					<input autocomplete="off" type="text" name="jasa_bln" value="<?php echo $data2['jasa_bln'];?>" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Tenor</label>
					<input autocomplete="off" type="text" name="tenor" value="<?php echo $data2['tenor'];?>" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Jasa (Tahun)</label>
					<input autocomplete="off" type="text" name="jasa_thn" value="<?php echo $data2['jasa_thn'];?>" required class="form-control"/>
				</div>

				<div class="form-group col-md-6">
					<label class="font-weight-bold">Pokok Bulanan</label>
					<input autocomplete="off" type="text" name="pokok_bln" value="<?php echo $data2['pokok_bln'];?>" required class="form-control"/>
				</div>

				<div class="form-group col-md-6">
					<label class="font-weight-bold">Jasa</label>
					<input autocomplete="off" type="text" name="jasa" value="<?php echo $data2['jasa'];?>" required class="form-control"/>
				</div>

				<div class="form-group col-md-6">
					<label class="font-weight-bold">Angsuran</label>
					<input autocomplete="off" type="text" name="angsuran" value="<?php echo $data2['angsuran'];?>" required class="form-control"/>
				</div>

				<div class="form-group col-md-6">
					<label class="font-weight-bold">Pembulatan</label>
					<input autocomplete="off" type="text" name="pembulatan" value="<?php echo $data2['pembulatan'];?>" required class="form-control"/>
				</div>
			</div>
		</div>
		<div class="card-footer text-right">
            <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Update</button>
            <button type="reset" class="btn btn-info"><i class="fa fa-sync-alt"></i> Reset</button>
        </div>
	</form>
</div>

<?php
}
?>

