<?php 
	include "config/koneksi.php";
	include "config/fungsi.php";

	$aksi=$_GET['aksi'];
	if(empty($aksi)){
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-users-cog"></i> Data Pengguna</h1>

    <a href="?pilih=datapengguna&aksi=tambah" class="btn btn-success"> <i class="fa fa-plus"></i> Tambah Data </a>
</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Daftar Data Pengguna</h6>
    </div>

    <div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Kode User</th>
						<th>Usernama</th>
						<th>Password</th>
						<th>Nama</th>
						<th>Level</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$sqlku=mysql_query("SELECT * from t_user");
						$no=1;
						while($data=mysql_fetch_array($sqlku)){
					?>
					<tr align="center">
						<td><?php echo $no;?></td>
						<td><?php echo $data['kode_user'];?></td>
						<td><?php echo $data['username'];?></td>
						<td><?php echo $data['password'];?></td>
						<td><?php echo $data['nama'];?></td>
						<td><?php echo $data['level'];?></td>
						<td>
							<div class="btn-group" role="group">
								<a data-toggle="tooltip" data-placement="bottom" title="Edit Data" href="?pilih=datapengguna&aksi=ubah&kode_user=<?php echo $data['kode_user'];?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a>
								
								<a data-toggle="tooltip" data-placement="bottom" title="Hapus Data" href="setting/proses_user.php?pros=hapus&kode_user=<?php echo $data['kode_user'];?>" onclick="return confirm ('Apakah anda yakin untuk meghapus data ini')" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
							</div>
						</td>
					</tr> 
					<?php
						$no++;}
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>    
<?php
	}elseif($aksi=='tambah'){
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-users-cog"></i> Data Pengguna</h1>

	<a href="?pilih=datapengguna" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
		<span class="text">Kembali</span>
	</a>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fas fa-fw fa-plus"></i> Tambah Data Pengguna</h6>
    </div>
	
	<form action="setting/proses_user.php?pros=tambah" method="post">
		<div class="card-body">
			<div class="row">
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Kode Pengguna</label>
					<input autocomplete="off" type="text" name="kode_user" value="<?php echo nomer("U","kode_user","t_user");?>" readonly required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Username</label>
					<input autocomplete="off" type="text" name="username" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Password</label>
					<input autocomplete="off" type="password" name="password" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Nama</label>
					<input autocomplete="off" type="text" name="nama" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Level</label>
					<select name="level" class="form-control" required>
						<option value="">--Pilih Level--</optiom>
						<option value="admin">Admin</optiom>
						<option value="operator">Operator</optiom>
					</select>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Tanggal Entri</label>
					<input autocomplete="off" type="text" name="tgl_entri" value="<?php echo date("Y-m-d");?>" readonly required class="form-control"/>
				</div>
			</div>
		</div>
		<div class="card-footer text-right">
            <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
            <button type="reset" class="btn btn-info"><i class="fa fa-sync-alt"></i> Reset</button>
        </div>
	</form>
</div>

<?php
}elseif($aksi=='ubah'){
$kode=$_GET['kode_user'];
$q=mysql_query("SELECT * FROM t_user WHERE kode_user='$kode'");
$data2=mysql_fetch_array($q);
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-users-cog"></i> Data Pengguna</h1>

	<a href="?pilih=datapengguna" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
		<span class="text">Kembali</span>
	</a>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fas fa-fw fa-edit"></i> Edit Data Pengguna</h6>
    </div>
	
	<form action="setting/proses_user.php?pros=ubah" method="post">
		<div class="card-body">
			<div class="row">
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Kode Pengguna</label>
					<input autocomplete="off" type="text" name="kode_user" value="<?php echo $data2['kode_user'];?>" readonly required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Username</label>
					<input autocomplete="off" type="text" name="username" value="<?php echo $data2['username'];?>" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Password</label>
					<input autocomplete="off" type="password" name="password" value="<?php echo $data2['password'];?>" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Nama</label>
					<input autocomplete="off" type="text" name="nama" value="<?php echo $data2['nama'];?>" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Level</label>
					<select name="level" class="form-control" required>
						<option value="">--Pilih Level--</optiom>
						<option value="admin" <?php if($data2['level']=='admin'){echo "selected";}?>>Admin</optiom>
						<option value="operator" <?php if($data2['level']=='operator'){echo "selected";}?>>Operator</optiom>
					</select>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Tanggal Entri</label>
					<input autocomplete="off" type="text" name="tgl_entri" value="<?php echo $data2['tgl_entri'];?>" readonly required class="form-control"/>
				</div>
			</div>
		</div>
		<div class="card-footer text-right">
            <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Update</button>
            <button type="reset" class="btn btn-info"><i class="fa fa-sync-alt"></i> Reset</button>
        </div>
	</form>
</div>

<?php
	}
?>

