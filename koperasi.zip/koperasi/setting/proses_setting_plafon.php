<?php 
	include "../config/koneksi.php";
	require ('root.php');
	$lib= new root();
	$pros=$_GET['pros'];
	$kode=$_GET['kode_plafon'];
	
	$id=$_POST['kode_plafon'];
	$jenis=$_POST['jenis_pinjaman'];
	$pokok=$_POST['pokok'];
	$jasa_bln=$_POST['jasa_bln'];
	$tenor=$_POST['tenor'];
	$jasa_thn=$_POST['jasa_thn'];
	$pokok_bln=$_POST['pokok_bln'];
	$jasa=$_POST['jasa'];
	$angsuran=$_POST['angsuran'];
	$pembulatan=$_POST['pembulatan'];

	switch ($pros){		
		case "tambah" :
			$lib->tambahplafon($kode,$id,$jenis,$pokok,$jasa_bln,$tenor,$jasa_thn,$pokok_bln,$jasa,$angsuran,$pembulatan);
				
		break;
		
		case "ubah" :
			$lib->ubahplafon($kode,$id,$jenis,$pokok,$jasa_bln,$tenor,$jasa_thn,$pokok_bln,$jasa,$angsuran,$pembulatan);
		break;		
		
		case "hapus" :
			$lib->hapusplafon($kode,$id,$jenis,$pokok,$jasa_bln,$tenor,$jasa_thn,$pokok_bln,$jasa,$angsuran,$pembulatan);
		break;
		
		default : break; 
	}
	
?>