<?php
session_start();

include "../config/koneksi.php";

// Dikirim dari form
$kode_anggota=$_POST['kode_anggota'];
$password=$_POST['password'];
$query=mysql_query("SELECT * FROM t_anggota WHERE kode_anggota='$kode_anggota' AND password='$password'");
$jumlah=mysql_num_rows($query);
$a=mysql_fetch_array($query);

if($jumlah > 0){
	$_SESSION['kopid']=$a['kode_anggota'];
	$_SESSION['kopname']=$a['nama_anggota'];
	header("location:../member/index.php?pilih=home");
}else{
?>
	<script>
		alert("Kode Anggota atau Password Salah!");
		window.location="login.php";
	</script>
<?php
}
?>

