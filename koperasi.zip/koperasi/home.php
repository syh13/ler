<?php
include "config/koneksi.php";
$ghu=mysql_query("SELECT * FROM t_tabungan");
$no=1;
while($dataku=mysql_fetch_array($ghu))
{
$fgh=$dataku['tgl_mulai'];$tang=date("Y-m-d");$kode_tab=$dataku['kode_tabungan'];
$tempo=date('Y-m-d',strtotime('+30 day',strtotime($fgh)));
if($tempo==$tang)
{
    $total=$dataku['besar_tabungan']+10000;
    $tol=mysql_query("UPDATE t_tabungan set tgl_mulai='$tang',besar_tabungan='$total' where kode_tabungan='$kode_tab'");
}
else
{
}
$no++;
} 
$a=mysql_query("SELECT * from t_anggota ");
$b=mysql_num_rows($a);
$c=mysql_fetch_array(mysql_query("SELECT SUM(besar_pinjam) as total_pinjam from t_pinjam"));
$d=mysql_fetch_array(mysql_query("SELECT SUM(besar_angsuran) as total_angsuran from t_angsur"));
$e=mysql_fetch_array(mysql_query("SELECT SUM(besar_tabungan) as total_tabungan from t_tabungan"));
$f=mysql_fetch_array(mysql_query("SELECT SUM(denda) as denda from t_angsur"));
$g=mysql_fetch_array(mysql_query("SELECT SUM(besar_pinjam) as besar_pinjam from t_pengajuan"));
?>

<div class="mb-4">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-home"></i> Dashboard</h1>
    </div>

    <!-- Content Row -->
    <div class="alert alert-success">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        Selamat datang <span class="text-uppercase"><b><?php echo $_SESSION['kopname'];?>!</b></span> Anda bisa mengoperasikan sistem dengan wewenang tertentu melalui pilihan menu di bawah.
    </div>
	
	<div class="row">
	<?php 
	if($_SESSION['level']=='admin') {
	?>
		<div class="col-xl-4 col-md-6 mb-4">
		<div class="card border-left-primary shadow h-100 py-2">
			<div class="card-body">
			<div class="row no-gutters align-items-center">
				<div class="col mr-2">
				<div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Data Anggota</div>
				<div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $b; ?></div>
				</div>
			</div>
			</div>
		</div>
		</div>
		
		<div class="col-xl-4 col-md-6 mb-4">
		<div class="card border-left-success shadow h-100 py-2">
			<div class="card-body">
			<div class="row no-gutters align-items-center">
				<div class="col mr-2">
				<div class="text-xs font-weight-bold text-success text-uppercase mb-1">Data Pinjaman</div>
				<div class="h5 mb-0 font-weight-bold text-gray-800">Rp. <?php echo number_format($c['total_pinjam']); ?></div>
				</div>
			</div>
			</div>
		</div>
		</div>
		
		<div class="col-xl-4 col-md-6 mb-4">
		<div class="card border-left-info shadow h-100 py-2">
			<div class="card-body">
			<div class="row no-gutters align-items-center">
				<div class="col mr-2">
				<div class="text-xs font-weight-bold text-info text-uppercase mb-1">Data Angsuran</div>
				<div class="h5 mb-0 font-weight-bold text-gray-800">Rp. <?php echo number_format($d['total_angsuran']); ?></div>
				</div>
			</div>
			</div>
		</div>
		</div>
		
		<div class="col-xl-4 col-md-6 mb-4">
		<div class="card border-left-warning shadow h-100 py-2">
			<div class="card-body">
			<div class="row no-gutters align-items-center">
				<div class="col mr-2">
				<div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Data Simpanan</div>
				<div class="h5 mb-0 font-weight-bold text-gray-800">Rp. <?php echo number_format($e['total_tabungan']); ?></div>
				</div>
			</div>
			</div>
		</div>
		</div>
		
	
	<?php
	} else if($_SESSION['level']=='operator'){
	?>
		<div class="col-xl-6 col-md-6 mb-4">
		<div class="card border-left-success shadow h-100 py-2">
			<div class="card-body">
			<div class="row no-gutters align-items-center">
				<div class="col mr-2">
				<div class="text-xs font-weight-bold text-success text-uppercase mb-1">Data Pinjaman</div>
				<div class="h5 mb-0 font-weight-bold text-gray-800">Rp. <?php echo number_format($c['total_pinjam']); ?></div>
				</div>
			</div>
			</div>
		</div>
		</div>
		
		<div class="col-xl-6 col-md-6 mb-4">
		<div class="card border-left-info shadow h-100 py-2">
			<div class="card-body">
			<div class="row no-gutters align-items-center">
				<div class="col mr-2">
				<div class="text-xs font-weight-bold text-info text-uppercase mb-1">Data Angsuran</div>
				<div class="h5 mb-0 font-weight-bold text-gray-800">Rp. <?php echo number_format($d['total_angsuran']); ?></div>
				</div>
			</div>
			</div>
		</div>
		</div>
		
		<div class="col-xl-6 col-md-6 mb-4">
		<div class="card border-left-warning shadow h-100 py-2">
			<div class="card-body">
			<div class="row no-gutters align-items-center">
				<div class="col mr-2">
				<div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Data Simpanan</div>
				<div class="h5 mb-0 font-weight-bold text-gray-800">Rp. <?php echo number_format($e['total_tabungan']); ?></div>
				</div>
			</div>
			</div>
		</div>
		</div>

		<div class="col-xl-4 col-md-6 mb-4">
		<div class="card border-left-primary shadow h-100 py-2">
			<div class="card-body">
			<div class="row no-gutters align-items-center">
				<div class="col mr-2">
				<div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Data Anggota</div>
				<div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $b; ?></div>
				</div>
			</div>
			</div>
		</div>
		</div>
		
		
	<?php
	}
	?>
	</div>
	<script>
	var ctx = document.getElementById("myChart").getContext('2d');
	var myChart = new Chart(ctx, {
		type: 'bar',
		data: {
			labels: ["Laki-laki", "Perempuan"],
			datasets: [{
				label: '',
				data: [
				<?php 
				$jumlah_laki =mysql_fetch_array(mysql_query("SELECT * FROM t_anggota WHERE jenis_kelamin='Laki-laki'"));
				echo mysql_num_rows($jumlah_laki);
				?>, 
				<?php 
				$jumlah_pr = mysql_fetch_array(mysql_query("SELECT * FROM t_anggota WHERE jenis_kelamin='Perempuan'"));
				echo mysql_num_rows($jumlah_pr);
				?>, 
				],
				backgroundColor: [
				'rgba(255, 99, 132, 0.2)',
				'rgba(54, 162, 235, 0.2)',
				'rgba(255, 206, 86, 0.2)',
				'rgba(75, 192, 192, 0.2)'
				],
				borderColor: [
				'rgba(255,99,132,1)',
				'rgba(54, 162, 235, 1)',
				'rgba(255, 206, 86, 1)',
				'rgba(75, 192, 192, 1)'
				],
				borderWidth: 1
			}]
		},
		options: {
			scales: {
				yAxes: [{
					ticks: {
						beginAtZero:true
					}
				}]
			}
		}
	});
</script>
</div>
