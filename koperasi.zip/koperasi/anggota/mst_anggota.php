<?php 
	include "config/koneksi.php";
	include "config/fungsi.php";

	$aksi=$_GET['aksi'];
	if(empty($aksi)){
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-users"></i> Data Anggota</h1>
	<div class="text-right">
		<a href="laporan/print_anggota.php" class="btn btn-primary"> <i class="fa fa-print"></i> Cetak Data </a>
    	<a href="?pilih=dataanggota&aksi=tambah" class="btn btn-success"> <i class="fa fa-plus"></i> Tambah Anggota </a>
	</div>
</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Daftar Anggota</h6>
    </div>

    <div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Kode Anggota</th>
						<th>Nama Anggota</th>
						<th>TTL</th>
						<th>Pekerjaan</th>
						<th>Tanggal Masuk</th>
						<th>Status</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<?php
				$query=mysql_query("SELECT * FROM t_anggota order by kode_anggota asc");
				$no=1;
				while($data=mysql_fetch_array($query)){
				?>
				<tr align="center">
					<td><?php echo $no;?></td>
					<td><?php echo $data['kode_anggota'];?></td>
					<td align="left"><?php echo $data['nama_anggota'];?></td>
					<td><?php echo $data['tempat_lahir'];?>, <?php echo $data['tgl_lahir'];?></td>
					<td><?php echo $data['pekerjaan'];?></td>
					<td><?php echo $data['tgl_masuk'];?></td>
					<td>
						<?php
						if ($data['status']=='aktif'){
							echo "<span class='badge badge-success'>Aktif</span>";
						} else {
							echo "<span class='badge badge-danger'>Keluar</span>";
						}
						?>
					</td>
					<td>
						<?php
						if ($data['status']=='aktif'){
						?>
						<div class="btn-group" role="group">
							<a data-toggle="tooltip" data-placement="bottom" title="Edit Data" href="?pilih=dataanggota&aksi=ubah&kode_anggota=<?php echo $data['kode_anggota'];?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a>
							
							<a data-toggle="tooltip" data-placement="bottom" title="Keluarkan Anggota" href="anggota/proses_anggota.php?pros=keluar&kode_anggota=<?php echo $data['kode_anggota'];?>" class="btn btn-primary btn-sm"><i class="fa fa-sign-out-alt"></i></a>
							
						</div>
						<?php
						} else {
						?>
						<?php
						}			
						?>
					</td>
					
				</tr>   
				<?php
				$no++;
				}
				?>
				</tbody>
			</table>
		</div>
	</div>
</div>

<?php
	}else if($aksi=='tambah'){
	$query=mysql_query("SELECT * FROM t_jenis_simpan WHERE nama_simpanan='pokok'");
	$data=mysql_fetch_array($query);
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-users"></i> Data Anggota</h1>

	<a href="?pilih=dataanggota" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
		<span class="text">Kembali</span>
	</a>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fas fa-fw fa-plus"></i> Tambah Data Anggota</h6>
    </div>
	
	<form action="anggota/proses_anggota.php?pros=tambah" method="post" id="form" role="form" enctype="multipart/form-data">
		<div class="card-body">
			<div class="row">
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Kode Anggota</label>
					<input autocomplete="off" type="text" name="kode_anggota" value="<?php echo nomer["kode_anggota"];?>" required class="form-control"/>
					<input autocomplete="off" type="hidden" name="password" value="<?php echo nomer["kode_anggota"];?>" class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Tanggal Masuk</label>
					<input autocomplete="off" type="date" name="tgl_masuk" value="<?php echo date("Y-m-d");?>" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Simpanan Pokok</label>
					<input autocomplete="off" type="text" name="simpanan_pokok" value="<?php echo $data['besar_simpanan'];?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Nama Lengkap</label>
					<input autocomplete="off" type="text" name="nama_anggota" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Jenis Kelamin</label>
					<select name="jenis_kelamin" class="form-control" required>
						<option value="">--Pilih Jenis Kelamin--</optiom>
						<option value="Laki-laki">Laki-laki</optiom>
						<option value="Perempuan">Perempuan</optiom>
					</select>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Tempat Lahir</label>
					<input autocomplete="off" type="text" name="tmp_lahir" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Tanggal Lahir</label>
					<input autocomplete="off" type="date" name="tgl_lahir" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Alamat</label>
					<input autocomplete="off" type="text" name="alamat_anggota" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Telp</label>
					<input autocomplete="off" type="text" name="telp" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Pekerjaan</label>
					<input autocomplete="off" type="text" name="pekerjaan" required class="form-control"/>
				</div>
			</div>
		</div>
	
		<div class="card-footer text-right">
            <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
            <button type="reset" class="btn btn-info"><i class="fa fa-sync-alt"></i> Reset</button>
        </div>
	</form>
</div>


<?php
	}else if($aksi=='ubah'){
	$kode=$_GET['kode_anggota'];
	$qubah=mysql_query("SELECT * FROM t_anggota WHERE kode_anggota='$kode'");
	$data2=mysql_fetch_array($qubah);
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-users"></i> Data Anggota</h1>

	<a href="?pilih=dataanggota" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
		<span class="text">Kembali</span>
	</a>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fas fa-fw fa-edit"></i> Edit Data Anggota</h6>
    </div>
	
	<form action="anggota/edit_anggota.php" method="get" id="form" role="form" enctype="multipart/form-data">
		<div class="card-body">
			<div class="row">
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Kode Anggota</label>
					<input autocomplete="off" type="text" name="kode_anggota" value="<?php echo $data2['kode_anggota'];?>" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Tanggal Masuk</label>
					<input autocomplete="off" type="date" name="tgl_masuk" value="<?php echo $data2['tgl_masuk'];?>" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Nama Lengkap</label>
					<input autocomplete="off" type="text" name="nama_anggota" required value="<?php echo $data2['nama_anggota'];?>" class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Password</label>
					<input autocomplete="off" type="text" name="password" required value="<?php echo $data2['password'];?>" class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Jenis Kelamin</label>
					<select name="jenis_kelamin" class="form-control" required>
						<option value="">--Pilih Jenis Kelamin--</optiom>
						<option value="Laki-laki" <?php if ($data2['jenis_kelamin'] == "Laki-laki"){echo "selected";}?>>Laki-laki</optiom>
						<option value="Perempuan" <?php if ($data2['jenis_kelamin'] == "Perempuan"){echo "selected";}?>>Perempuan</optiom>
					</select>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Tempat Lahir</label>
					<input autocomplete="off" type="text" name="tmp_lahir" required value="<?php echo $data2['tempat_lahir'];?>" class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Tanggal Lahir</label>
					<input autocomplete="off" type="date" name="tgl_lahir" required value="<?php echo $data2['tgl_lahir'];?>" class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Alamat</label>
					<input autocomplete="off" type="text" name="alamat_anggota" required value="<?php echo $data2['alamat_anggota'];?>" class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Telp</label>
					<input autocomplete="off" type="text" name="telp" required value="<?php echo $data2['telp'];?>" class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Pekerjaan</label>
					<input autocomplete="off" type="text" name="pekerjaan" required value="<?php echo $data2['pekerjaan'];?>" class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Tanggal Entri</label>
					<input autocomplete="off" type="text" name="tgl_entri" value="<?php echo date("Y-m-d");?>" required class="form-control" readonly="readonly"/>
				</div>
			
			</div>
		</div>
	
		<div class="card-footer text-right">
            <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Update</button>
            <button type="reset" class="btn btn-info"><i class="fa fa-sync-alt"></i> Reset</button>
        </div>
	</form>
</div>
<?php
}
?>