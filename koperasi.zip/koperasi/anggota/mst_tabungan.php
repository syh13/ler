<?php 
include "config/koneksi.php";
include "config/fungsi.php";
$aksi=$_GET['aksi'];

if(empty($aksi)) {
$ghu=mysql_query("SELECT * FROM t_tabungan");
$no=1;
while($dataku=mysql_fetch_array($ghu)) {
$fgh=$dataku['tgl_mulai'];$tang=date("Y-m-d");$kode_tab=$dataku['kode_tabungan'];
$tempo=date('Y-m-d',strtotime('+30 day',strtotime($fgh)));
	if($tempo==$tang){
		$total=$dataku['besar_tabungan']+10000;
		$tol=mysql_query("UPDATE t_tabungan set tgl_mulai='$tang',besar_tabungan='$total' where kode_tabungan='$kode_tab'");
	}else{
	}
$no++;
}
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-money-bill-wave"></i> Simpanan</h1>
	
	<a href="laporan/print_tabungan.php" class="btn btn-primary"> <i class="fa fa-print"></i> Cetak Data </a>
</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Simpanan</h6>
    </div>

    <div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Kode Simpanan</th>
						<th>Kode Anggota</th>
						<th>Nama Anggota</th>
						<th>Investasi (1 Bulan)</th>
						<th>Jumlah Saldo</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<tbody>
				<?php
					$query=mysql_query("SELECT * FROM t_tabungan order by kode_tabungan desc");
					$no=1;
					while($data=mysql_fetch_array($query)){
				?>
					<tr align="center">
						<td><?php echo $no;?></td>
						<td><?php echo $data['kode_tabungan'];?></td>
						<td><?php echo $data['kode_anggota'];?></td>
						
						<?php
							$d=$data['kode_anggota'];
							$f=mysql_fetch_array(mysql_query("SELECT nama_anggota from t_anggota where Kode_anggota='$d'"));
							$rty=mysql_fetch_array(mysql_query("SELECT sum(besar_simpanan) as total_asli from t_simpan where Kode_anggota='$d'"));
							$inves=$data['besar_tabungan']-$rty['total_asli'];
						?>
						<td align="left"><?php echo $f['nama_anggota'];?></td>
						
						<td><?php echo $data['tgl_mulai'];?> s/d <?php echo $tempo=date('Y-m-d',strtotime('+30 day',strtotime($data['tgl_mulai'])));?></td>
						<td>Rp. <?php echo Rp($data['besar_tabungan']);?></td> 
						<td>
							<a data-toggle="tooltip" data-placement="bottom" title="Ambil Uang" href="index.php?pilih=datatabungan&aksi=viewambil&kode_tabungan=<?php echo $data['kode_tabungan'];?>&kode_anggota=<?php echo $d;?>" class="btn btn-success btn-sm"><i class="fa fa-money-bill-wave"></i></a>
						</td>
					</tr> 
				<?php
				$no++;}
				?>
				</tbody>
			</table>
		</div>
		<div class="alert alert-info mt-3">
		Total Saldo Simpanan Anggota Adalah <b>Rp. <?php $bu=mysql_fetch_array(mysql_query("SELECT sum(besar_tabungan) as besar_tab from t_tabungan")); echo number_format($bu['besar_tab']);?></b>
		</div>
	</div>
</div>

<?php
}else if($aksi=='viewambil') {
$lo=$_GET['kode_tabungan'];
$luy=$_GET['kode_anggota'];
$nama=mysql_fetch_array(mysql_query("SELECT nama_anggota from t_anggota where Kode_anggota='$luy'"));
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-money-bill-wave"></i> Simpanan</h1>

	<a href="?pilih=datatabungan" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
		<span class="text">Kembali</span>
	</a>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fas fa-fw fa-table"></i> Pengambilan Simpanan <?php echo $nama['nama_anggota']; ?></h6>
    </div>
	
	<form action="anggota/proses_tabungan.php" method="get">
		<div class="card-body">
			<div class="row">
				<input type="hidden" value="<?php echo $lo; ?>" name="kode_tabungan">
				<input type="hidden" value="<?php echo $luy; ?>" name="kode_anggota"> 
				<?php $rtyu=mysql_fetch_array(mysql_query("SELECT *FROM t_tabungan where kode_tabungan='$lo' and kode_anggota='$luy'")); ?>
				<div class="form-group col-md-4">
					<label class="font-weight-bold">Total Saldo</label>
					<input autocomplete="off" type="text" id="txt1" onkeyup="sum();" name="saldo" value="<?php echo $rtyu['besar_tabungan'];?>" required class="form-control" readonly="readonly"/>
				</div>
				<script>
					function sum() {
					var txtFirstNumberValue = document.getElementById('txt1').value;
					var txtSecondNumberValue = document.getElementById('txt2').value;
					var result = parseInt(txtFirstNumberValue) - parseInt(txtSecondNumberValue);
					if (!isNaN(result)) {
					document.getElementById('txt3').value = result;
					}
					else{
					document.getElementById('txt3').value = txtFirstNumberValue;
					}
					}
					function isNumberKey(evt)
					{
					var charCode = (evt.which) ? evt.which : event.keyCode
					if (charCode > 31 && (charCode < 48 || charCode > 57))

					return false;
					return true;
					}
				</script>
  
				<div class="form-group col-md-4">
					<label class="font-weight-bold">Besar Ambil Uang</label>
					<input autocomplete="off" type="text" id="txt2" onkeyup="sum();" onkeypress="return isNumberKey(event)" name="besar_ambil" required class="form-control" />
				</div>
				
				<div class="form-group col-md-4">
					<label class="font-weight-bold">Sisa Uang</label>
					<input autocomplete="off" type="text" id="txt3" onkeyup="sum();" onkeypress="return isNumberKey(event)" required class="form-control" readonly="readonly"/>
				</div>
			</div>
		</div>
		<div class="card-footer text-right">
            <button class="btn btn-success"><i class="fa fa-check"></i> Ambil Uang</button>
            <button type="reset" class="btn btn-info"><i class="fa fa-sync-alt"></i> Reset</button>
        </div>
	</form>
</div>
	

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Data Riwayat Pengambilan Uang <?php echo $nama['nama_anggota']; ?></h6>
    </div>

    <div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Kode Ambil</th>
						<th>Kode Anggota</th>
						<th>Nama Anggota</th>
						<th>Kode Simpanan</th>
						<th>Besar Ambil</th>
						<th>Tanggal Ambil</th>
					</tr>
				</thead>
				<tbody>
				<?php
				  $query=mysql_query("SELECT * FROM t_pengambilan where kode_anggota='$luy' and kode_tabungan='$lo' order by kode_ambil desc");
				  $no=1;
				  while($data=mysql_fetch_array($query)){
				?>
					<tr align="center">
						<td><?php echo $no;?></td>
						<td><?php echo $data['kode_ambil'];?></td>
						<td><?php echo $data['kode_anggota'];?></td>
						<?php
							$d=$data['kode_anggota'];
							$f=mysql_fetch_array(mysql_query("SELECT nama_anggota from t_anggota where Kode_anggota='$d'"));
							$rty=mysql_fetch_array(mysql_query("SELECT sum(besar_simpanan) as total_asli from t_simpan where Kode_anggota='$d'"));
							$inves=$data['besar_tabungan']-$rty['total_asli'];
						?>
						<td><?php echo $f['nama_anggota'];?></td>
						<td><?php echo $data['kode_tabungan'];?></td>
						<td>Rp. <?php echo number_format($data['besar_ambil']);?></td>
						<td><?php echo $data['tgl_ambil'];?></td>
					</tr> 
					<?php
					$no++;} //tutup while
					?>
				</tbody>
			</table>
		</div>
		<div class="alert alert-info mt-3">
		Total Saldo Yang Diambil Adalah <b>Rp. <?php $bu=mysql_fetch_array(mysql_query("SELECT sum(besar_ambil) as besar_ambil from t_pengambilan where kode_anggota='$luy'")); echo number_format($bu['besar_ambil']);?></b>
		</div>
	</div>
</div>
<?php
}
?>
