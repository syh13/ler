<?php 
$aksi=$_GET['aksi'];
if($aksi=='admin')
{
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-location-arrow"></i> Pengajuan Pinjaman</h1>
</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Pengajuan Pinjaman</h6>
    </div>

    <div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Nama Anggota</th>
						<th>Tanggal Pengajuan</th>
						<th>Besar Pinjam</th>
						<th>Jenis Pinjam</th>
						<th>Status</th>
						<th>Tanggal Terima</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<tbody>
					<?php
						include "config/koneksi.php";
						$sqlku=mysql_query("SELECT * from t_pengajuan order by kode_pengajuan desc");
						$no=1;
						while($data=mysql_fetch_array($sqlku)){
					?>

					<tr align="center">
						<td><?php echo $no;?></td>
						<?php
							$isi=$data['kode_anggota'];
							$ang=mysql_fetch_array(mysql_query("SELECT * from t_anggota where kode_anggota='$isi'"));
						?>
						<td><?php echo $ang['nama_anggota'];?> (<?php echo $isi;?>)</td>
						<td><?php echo $data['tgl_pengajuan'];?></td>
						<td>Rp. <?php echo number_format($data['besar_pinjam']);?></td>
						<?php
							$rr=$data['kode_jenis_pinjam'];
							$oo=mysql_fetch_array(mysql_query("SELECT*from t_jenis_pinjam where kode_jenis_pinjam='$rr'"));
							$asli=$data['besar_pinjam']/$oo['lama_angsuran'];
							$bung=$oo['bunga']/100;
							$bunganya=$data['besar_pinjam']*$bung;
							$total=$asli+$bunganya;
						?>
						<td><?php echo $oo['nama_pinjaman'];?></td>
						<td>
							<?php if($data['status']=='diterima'){
								echo "<span class='badge badge-success'>Diterima</span>";
							} else if($data['status']=='ditolak'){
								echo "<span class='badge badge-danger'>Ditolak</span>";
							} else{
								echo "<span class='badge badge-info'>Menunggu</span>";
							}
							?>
						</td>
						<td>
							<?php if($data['status']=='diterima'){
								echo $data['tgl_acc'];
							} else {
								echo "Tanggal Tidak Tersedia";
							}
							?>
						</td>
						<?php if($data['status']=='menunggu')
						{?>
						<td>
							<div class="btn-group" role="group">
								<a data-toggle="tooltip" data-placement="bottom" title="Terima Pengajuan" href="pengajuan/proses_pengajuan.php?proses=terima&kode_anggota=<?php echo $isi;?>&kode_pengajuan=<?php echo $data['kode_pengajuan'];?>" class="btn btn-primary btn-sm"><i class="fa fa-check"></i></a>
								
								<a data-toggle="tooltip" data-placement="bottom" title="Tolak Pengajuan" href="pengajuan/proses_pengajuan.php?proses=tolak&kode_anggota=<?php echo $isi;?>&kode_pengajuan=<?php echo $data['kode_pengajuan'];?>" class="btn btn-danger btn-sm"><i class="fa fa-window-close"></i></a>
							</div>
						</td>
					<?php } ?>
					</tr> 

					<?php
						$no++;
						}
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>

<?php
}
?>