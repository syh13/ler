<?php 
	include "config/koneksi.php";
	include "config/fungsi.php";

	$aksi=$_GET['aksi'];	
?>

<!-- SIMPANAN -->
<script language="JavaScript">

$(document).ready(function(){
	$(function() {
		$( '#tanggal' ).datepicker({
			dateFormat:'yy-mm-dd',
			changeMonth: true,
			changeYear: true
		});
		$( '#tgl' ).datepicker({
			dateFormat:'yy-mm-dd',
			changeMonth: true,
			changeYear: true
		});
	});
});
// fungsi untuk get besar_simpanan
function show(kode_jenis_simpan){
	$.ajax({
		type : "POST",
		data : "kode_jenis_simpan="+kode_jenis_simpan,
		url  : "dataSimpanan.php",
		success : function(msg){
			hasil = jQuery.parseJSON(msg);
			if(hasil.NAMA_SIMPANAN!=""){
				$('#besar_simpanan').val(hasil.BESAR_SIMPANAN);				
			}else{
				$('#besar_simpanan').val("");				
			}
		}
	})
}
$(document).ready(function(){
	$("#kategori").change(function(){
		var kat = $("#kategori").val();
		if (kat == "tgl_simpan"){
			$("#cari").html('<input type=\"text\" name=\"input_cari\" id=\"tgl\" onclick=\"datePicker("tgl")\"/>');
		}else{
			$("#cari").html('<input type="text" name="input_cari" id="cari"/>');
		}
	});
});
</script>

<!-- PINJAMAN -->
<script language="JavaScript">
	// fungsi untuk get besar_simpanan
function show3(kode_jenis_pinjam){
	$.ajax({
		type : "POST",
		data : "kode_jenis_pinjam="+kode_jenis_pinjam,
		url : "dataJenisPinjaman.php",
		success : function(msg){
			hasil = jQuery.parseJSON(msg);
			if(hasil.NAMA_PINJAMAN!=""){
				$('#lama_angsuran').val(hasil.LAMA_ANGSURAN);
				$('#maks_pinjam').val(hasil.MAKS_PINJAM);
				$('#bunga').val(hasil.BUNGA);
			}else{		
				$('#lama_angsuran').val("");
				$('#maks_pinjam').val("");
			}
		}
	})
}
// menghitung pinjaman
	function startCalc(){
		interval = setInterval("calc()",1);
	}
//menghitung ansuran
	function calc(){
		a = document.frmAdd.besar_pinjaman.value;
		f = document.frmAdd.bunga.value/100;
		e = document.frmAdd.maks_pinjam.value;
		b = document.frmAdd.lama_angsuran.value;
		g = a * f;
		i = a / b;
		h = parseInt(g)+parseInt(i);
		c = document.frmAdd.besar_angsuran.value = h ;
	} 
	function stopCalc(){
		clearInterval(interval);
	} 
</script>

<!-- ANGSURAN -->
<script language="JavaScript">
// fungsi untuk get besar_simpanan
function show2(kode_pinjam){
	$.ajax({
		type : "POST",
		data : "kode_pinjam="+kode_pinjam,
		url  : "dataPinjaman.php",
		success : function(msg){
			hasil = jQuery.parseJSON(msg);
			if(hasil.TGL_PINJAM!=""){
				$('#tgl_pinjam').val(hasil.TGL_PINJAM);	
				$('#besar_pinjam').val(hasil.BESAR_PINJAM);
				var a=$('#lama_angsuran').val(hasil.LAMA_ANGSURAN);
				$('#besar_angsuran').val(hasil.BESAR_ANGSURAN);
				var b=$('#angsuran_ke').val(hasil.SISA_ANGSURAN);
					

			}else{
				$('#besar_simpanan').val("");				
			}
		}
	})
}
</script>

<script type="text/javascript">
      $(document).ready(function() {
        $("#cari").keyup(function(){
        $("#fbody").find("tr").hide();
        var data = this.value.split("");
        var jo = $("#fbody").find("tr");
        $.each(data, function(i, v)
        {
              jo = jo.filter("*:contains('"+v+"')");
        });
          jo.fadeIn();

        })
  });
</script>



<?php
	if(empty($aksi)){
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-dolly-flatbed"></i> Data Transaksi</h1>
</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Transaksi Simpan Pinjam</h6>
    </div>

    <div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Kode Anggota</th>
						<th>Nama Anggota</th>
						<th>Pekerjaan</th>
						<th>Tanggal Masuk</th>
						<th>Aksi</th>
					</tr>	
				</thead>
				<tbody>
				<?php
				$query=mysql_query("SELECT * FROM t_anggota where status='aktif' ORDER BY kode_anggota ASC");
				$no=1;		
				while($data=mysql_fetch_array($query)){
				?>
					<tr align="center">
						<td><?php echo $no;?></td>
						<td><?php echo $kod=$data['kode_anggota'];?></td>
						<td><?php echo $data['nama_anggota'];?></td>
						<td><?php echo $data['pekerjaan'];?></td>
						<td><?php echo $data['tgl_masuk'];?></td>
						<td>
							<div class="btn-group" role="group">
								<a data-toggle="tooltip" data-placement="bottom" title="Transaksi Simpanan" href="?pilih=datatransaksi&aksi=simpanananggota&kode_anggota=<?php echo $data['kode_anggota'];?>" class="btn btn-success btn-sm"><i class="fa fa-money-bill-wave"></i></a>
								
								<a data-toggle="tooltip" data-placement="bottom" title="Transaksi Pinjam/Angsur" href="?pilih=datatransaksi&aksi=pinjamangsur&kode_anggota=<?php echo $data['kode_anggota'];?>" class="btn btn-primary btn-sm"><i class="fa fa-money-bill-wave"></i></a>
								
								<?php
								if($_SESSION['level']=='operator') {
								?>
								<a data-toggle="tooltip" data-placement="bottom" title="Transaksi Pengajuan" href="?pilih=datapengajuan&aksi=operator&kode_anggota=<?php echo $data['kode_anggota'];?>" class="btn btn-info btn-sm"><i class="fa fa-money-bill-wave"></i></a>
								<?php
								}
								?>
							</div>
						</td>
					</tr>  
					<?php
					$no++;
					}
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>
    
<?php
	}elseif($aksi=='simpan'){
		$kode=$_GET['kode_anggota'];
		$kode_jenis=$_GET['kode_jenis_simpan'];
		$nama=mysql_fetch_array(mysql_query("SELECT *from t_jenis_simpan where kode_jenis_simpan='$kode_jenis'"));
		$qubah=mysql_query("SELECT * FROM t_anggota WHERE kode_anggota='$kode'");
		$data2=mysql_fetch_array($qubah);
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-dolly-flatbed"></i> Data Transaksi</h1>

	<a href="?pilih=datatransaksi&aksi=simpanananggota&kode_anggota=<?php echo $kode; ?>" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
		<span class="text">Kembali</span>
	</a>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fas fa-fw fa-plus"></i> Tambah Simpanan</h6>
    </div>
	
	<form action="transaksi/proses_transaksi.php?pros=simpan" method="post" id="form" name="mainform" onSubmit="validasiSimpan()">
		<div class="card-body">
			<div class="row">
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Kode Anggota</label>
					<input autocomplete="off" type="text" name="kode_anggota" value="<?php echo $data2['kode_anggota'];?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Nama Anggota</label>
					<input autocomplete="off" type="text" name="nama_anggota" value="<?php echo $data2['nama_anggota'];?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Pekerjaan</label>
					<input autocomplete="off" type="text" name="pekerjaan" value="<?php echo $data2['pekerjaan'];?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Jenis Simpanan</label>
					<select name="kode_jenis_simpan" id="kode_jenis_simpan" onChange="show(this.value)" class="form-control" required>
						<option value="<?php echo $kode_jenis;?>"><?php echo $nama['nama_simpanan'];?></option>			  
					</select>
				</div>
				
				<?php
				if($nama['nama_simpanan']=='sukarela'){
				?>
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Besar Simpanan</label>
					<input autocomplete="off" type="number" name="besar_simpanan" value="<?php echo $nama['besar_simpanan'];?>" required class="form-control"/>
				</div>
				<?php
				}else{
				?>
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Besar Simpanan</label>
					<input autocomplete="off" type="number" name="besar_simpanan" value="<?php echo $nama['besar_simpanan'];?>" required readonly class="form-control"/>
				</div>
				<div class="form-group col-md-6">
					<label class="font-weight-bold">User Entri</label>
					<input autocomplete="off" type="text" name="user_entri" value="<?php session_start(); echo $_SESSION['kopname'];?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Tanggal Entri</label>
					<input autocomplete="off" type="text" name="tgl_entri" value="<?php echo date("Y-m-d");?>" required class="form-control" readonly="readonly"/>
				</div>
				<?php } ?>				
			</div>
		</div>
		<div class="card-footer text-right">
            <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
            <button type="reset" class="btn btn-info"><i class="fa fa-sync-alt"></i> Reset</button>
        </div>
	</form>
</div>
<?php
	}else if($aksi=='pinjam'){
		$kode=$_GET['kode_anggota'];
		$qubah=mysql_query("SELECT * FROM t_anggota WHERE kode_anggota='$kode'");
		$data2=mysql_fetch_array($qubah);
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-dolly-flatbed"></i> Data Transaksi</h1>

	<a href="?pilih=datatransaksi&aksi=pinjamangsur&kode_anggota=<?php echo $kode; ?>" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
		<span class="text">Kembali</span>
	</a>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fas fa-fw fa-plus"></i> Pengajuan Pinjaman</h6>
    </div>
	
	<form action="transaksi/proses_pinjam.php" method="GET" id="form" name="frmAdd">
		<div class="card-body">
			<div class="row">
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Kode Anggota</label>
					<input autocomplete="off" type="text" name="kode_anggota" value="<?php echo $data2['kode_anggota'];?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Nama Anggota</label>
					<input autocomplete="off" type="text" name="nama_anggota" value="<?php echo $data2['nama_anggota'];?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Pekerjaan</label>
					<input autocomplete="off" type="text" name="pekerjaan" value="<?php echo $data2['pekerjaan'];?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Jenis Pinjaman</label>
					<select name="kode_jenis_pinjam" class="form-control" id="kode_jenis_pinjam" onChange="show3(this.value)" required>
						<option value="">--Pilih Jenis Pinjaman--</optiom>
					<?php
						$q=mysql_query("SELECT * FROM t_jenis_pinjam");
						while($a=mysql_fetch_array($q)){
					?>
						<option value="<?php echo $a['kode_jenis_pinjam'];?>"><?php echo $a['nama_pinjaman'];?></option>
					<?php
					}
					?>
					</select>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Lama Angsuran (Bulan)</label>
					<input autocomplete="off" type="number" name="lama_angsuran" id="lama_angsuran" required readonly class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Maks Peminjaman</label>
					<input autocomplete="off" type="number" name="maks_pinjam" id="maks_pinjam" required readonly class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Bunga (%)</label>
					<input autocomplete="off" type="number" id="bunga" required readonly class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Besar Pinjaman</label>
					<input autocomplete="off" type="number" name="besar_pinjaman" id="besar_pinjaman" required class="form-control"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Angsuran</label>
					<input autocomplete="off" type="number" name="besar_angsuran" id="besar_angsuran" onFocus="startCalc();" onBlur="stopCalc();" readonly required readonly class="form-control"/>
				</div>
			</div>
		</div>
		<div class="card-footer text-right">
            <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
            <button type="reset" class="btn btn-info"><i class="fa fa-sync-alt"></i> Reset</button>
        </div>
	</form>
</div>
<?php
	}else if($aksi=='angsur')
	{
		$kode=$_GET['kode_anggota'];
		$kodep=$_GET['kode_pinjam'];
		$jio=mysql_fetch_array(mysql_query("SELECT * from t_pinjam where kode_pinjam='$kodep' "));

		$qubah=mysql_query("SELECT * FROM t_anggota WHERE kode_anggota='$kode'");
		$data2=mysql_fetch_array($qubah);
?>


<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-dolly-flatbed"></i> Data Transaksi</h1>

	<a href="?pilih=datatransaksi&aksi=pinjamangsur&kode_anggota=<?php echo $kode; ?>" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
		<span class="text">Kembali</span>
	</a>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fas fa-fw fa-plus"></i> Bayar Angsuran</h6>
    </div>
	
	<form action="transaksi/proses_transaksi.php?pros=angsur" method="post" id="form" name="frmAdd">
		<div class="card-body">
			<div class="row">
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Kode Anggota</label>
					<input autocomplete="off" type="text" name="kode_anggota" value="<?php echo $data2['kode_anggota'];?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Nama Anggota</label>
					<input autocomplete="off" type="text" name="nama_anggota" value="<?php echo $data2['nama_anggota'];?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Kode Pinjam</label>
					<input autocomplete="off" type="text" name="kode_pinjam" value="<?php echo $_GET['kode_pinjam']; ?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Tanggal Pinjam</label>
					<input autocomplete="off" type="text" name="tgl_pinjam" value="<?php echo $jio['tgl_entri'];?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Besar Pinjam</label>
					<input autocomplete="off" type="text" name="besar_pinjam" value="<?php echo number_format ($jio['besar_pinjam']);?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Lama Angsur</label>
					<input autocomplete="off" type="text" name="lama_angsuran" value="<?php echo $jio['lama_angsuran'];?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Angsuran</label>
					<input autocomplete="off" type="text" name="besar_angsur" value="<?php echo ($jio['besar_angsuran']);?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Angsuran Ke</label>
					<input autocomplete="off" type="text" name="angsuran_ke" value="<?php echo $jio['sisa_angsuran']+1;?>" required class="form-control" readonly="readonly"/>
				</div>
				
				<?php 	
					$kk=mysql_fetch_array(mysql_query("SELECT * from t_pinjam where kode_pinjam='$kodep' and kode_anggota='$kode'"));$tempo=$kk['tgl_tempo'];$dat=date("Y-m-d");
					if($dat>$tempo){
					$go=round($telat=((abs(strtotime($dat)-strtotime($tempo)))/(60*60*24))); $denda=$go * 1000;
				?>
				<div class="form-group col-md-6">
					<label class="font-weight-bold">Denda</label>
					<input autocomplete="off" type="text" name="denda" value="<?php echo $denda; ?>" required class="form-control" readonly="readonly"/>
				</div>
				<?php
				}else{
				?>
				<input type="hidden" class="form-control" name="denda" value="0">
				<?php
				}
				?>
			</div>
		</div>
		<div class="card-footer text-right">
            <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Bayar Angsuran</button>
            <button type="reset" class="btn btn-info"><i class="fa fa-sync-alt"></i> Reset</button>
        </div>
	</form>
</div>


<?php
	}else if($aksi=='pinjamangsur'){
		$kode=$_GET['kode_anggota']; $anggota=mysql_fetch_array(mysql_query("SELECT nama_anggota from t_anggota where kode_anggota='$kode'"));
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-dolly-flatbed"></i> Data Transaksi</h1>

    <div>
	 <?php
	 $df=mysql_fetch_array(mysql_query("SELECT * FROM t_pinjam where kode_anggota='$kode' order by kode_pinjam desc"));
	 $op=mysql_num_rows($df);
        if($df['status']=='belum lunas'){
			echo '<a href="?pilih=datatransaksi&aksi=pinjam" class="btn btn-success disabled"> <i class="fa fa-plus"></i> Tambah Pinjaman </a>';
        }else if($df['status']=='lunas'){
			echo '<a href="?pilih=datatransaksi&aksi=pinjam&kode_anggota='.$kode.'" class="btn btn-success"> <i class="fa fa-plus"></i> Tambah Pinjaman </a>';
        }else if($op<=0){
			echo '<a href="?pilih=datatransaksi&aksi=pinjam&kode_anggota='.$kode.'" class="btn btn-success"> <i class="fa fa-plus"></i> Tambah Pinjaman </a>';
        }
	?>
	<a href="?pilih=datatransaksi" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
		<span class="text">Kembali</span>
	</a>
	</div>
</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Pinjaman <?php echo $anggota['nama_anggota'];?></h6>
    </div>

    <div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Tangggal Pinjam</th>
						<th>Jenis Pinjam</th>
						<th>Besar Pinjam</th>
						<th>Lama Angsuran</th>
						<th>Jatuh Tempo</th>
						<th>Status</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$sql=mysql_query("SELECT * from t_pinjam where kode_anggota='$kode' order by kode_pinjam desc");
						$nomer=1;
						while($data=mysql_fetch_array($sql)){
							$kd_a=$data['kode_anggota'];
							$kd_j=$data['kode_jenis_pinjam'];
							$jenis=mysql_fetch_array(mysql_query("SELECT nama_pinjaman from t_jenis_pinjam where kode_jenis_pinjam='$kd_j'"));
					?>
					<tr align="center">
						<td><?php echo $nomer;?></td>
						<td><?php echo $data['tgl_entri'];?></td>
						<td><?php echo $jenis['nama_pinjaman'];?></td>
						<td><?php echo number_format($data['besar_pinjam']);?></td>
						<td><?php echo $data['sisa_angsuran'].' Bulan Dari '.$data['lama_angsuran'];?> Bulan</td>
						<td><?php echo $data['tgl_tempo'];?></td>
						<td>
							<?php
								if ($data['status']=='lunas'){
									echo "<span class='badge badge-success'>Lunas</span>";
								}else {
									echo "<span class='badge badge-danger'>Belum Lunas</span>";
								}?>
						</td>
						<td>
							<div class="btn-group" role="group">
								<a data-toggle="tooltip" data-placement="bottom" title="Detail Pinjaman" href="?pilih=datatransaksi&aksi=show&kode_anggota=<?php echo $data['kode_anggota'];?>&kode_pinjam=<?php echo $data['kode_pinjam']?>" class="btn btn-success btn-sm"><i class="fa fa-eye"></i></a>
								
								<?php
									$dfo=mysql_num_rows(mysql_query("SELECT *from t_angsur where kode_pinjam='$kd_p' and kode_anggota='$kode'"));
									if($dfo==$data['lama_angsuran']){
									}else {
										echo '<a data-toggle="tooltip" data-placement="bottom" title="Bayar Angsuran" href="?pilih=datatransaksi&aksi=angsur&kode_anggota='.$data['kode_anggota'].'&kode_pinjam='.$data['kode_pinjam'].'" class="btn btn-primary btn-sm"><i class="fa fa-check"></i></a>';
									}
								?>
							</div>
						</td>
					</tr>
					<?php
						$nomer++;
						}
					?> 
				</tbody>   
			</table>
		</div>
	</div>
</div>
<?php }
elseif($aksi=='simpanananggota'){
	$kode=$_GET['kode_anggota'];
	$q=mysql_query("SELECT *from t_anggota where kode_anggota='$kode'");
	$ang=mysql_fetch_array($q); 
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-dolly-flatbed"></i> Data Transaksi</h1>
	
	<div>
		<?php 
			$rino=mysql_query("SELECT*FROM t_jenis_simpan");
			$no=1;
			while($verida=mysql_fetch_array($rino)){ 
				if($verida['nama_simpanan']=='wajib'){
					$baru=mysql_fetch_array(mysql_query("SELECT *FROM t_simpan where kode_anggota='$kode' and jenis_simpan='wajib' order by kode_simpan desc "));$numrow=mysql_num_rows($baru);
					$data=$baru['tgl_mulai'];
					$now=date("Y-m-d");
					if($data==$now){
						echo '<a href="?pilih=datatransaksi&aksi=simpan&kode_anggota='.$kode.'&kode_jenis_simpan='.$verida['kode_jenis_simpan'].'" class="btn btn-success mr-1"> <i class="fa fa-plus"></i> Wajib '.$data.'</a>';
					} else if($data<$now){
						echo '<a href="?pilih=datatransaksi&aksi=simpan&kode_anggota='.$kode.'&kode_jenis_simpan='.$verida['kode_jenis_simpan'].'" class="btn btn-success mr-1"> <i class="fa fa-plus"></i> Wajib '.$data.'</a>';
					}else if($data>$now){
						echo '<a href="?pilih=datatransaksi&aksi=simpan&kode_anggota='.$kode.'&kode_jenis_simpan='.$verida['kode_jenis_simpan'].'" class="btn btn-success disabled mr-1"> <i class="fa fa-plus"></i> Wajib '.$data.'</a>';
					}
				}else if($verida['nama_simpanan']=='sukarela'){
					echo '<a href="?pilih=datatransaksi&aksi=simpan&kode_anggota='.$kode.'&kode_jenis_simpan='.$verida['kode_jenis_simpan'].'" class="btn btn-info"> <i class="fa fa-plus"></i> Sukarela</a>';
				}
			$no++;
			}
		?>
		<a href="laporan/print_show_simpanan.php?kode=<?php echo $ang['kode_anggota'];?>" class="btn btn-primary"> <i class="fa fa-print"></i> Print </a>
		<a href="?pilih=datatransaksi" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
			<span class="text">Kembali</span>
		</a>
	</div>
</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Simpanan <?php echo $ang['nama_anggota'];?></h6>
    
		
	</div>

    <div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Tanggal Simpan</a></th>
						<th>Nama Simpanan</a></th>
						<th>Besar Simpanan</a></th>
					</tr>
				</thead>
				<?php
					$query = mysql_query("SELECT * from t_simpan where kode_anggota='$kode'order by kode_simpan desc");
					echo '<tbody>';	
					$no=1;
					while($data=mysql_fetch_array($query)){
				?>
					<tr align="center">
						<td><?php echo $no?></td>
						<td><?php echo Tgl($data['tgl_entri']);?></td>
						<td><?php echo $data['jenis_simpan'];?></td>
						<td align="right">Rp. <?php echo Rp($data['besar_simpanan']);?></td>
					</tr> 
					<?php
						$no++;}
					?>
				</tbody>   
			</table>
		</div>
		<div class="alert alert-info mt-3">
		Total Saldo Simpanan Adalah <b>Rp. <?php $bu=mysql_fetch_array(mysql_query("SELECT sum(besar_simpanan) as besar_simpan from t_simpan where kode_anggota='$kode'")); echo Rp($bu['besar_simpan']);?></b>
		</div>
	</div>
</div>             
<?php
}elseif($aksi=='show'){
	$kode=$_GET['kode_anggota'];
	$kode_pinjam=$_GET['kode_pinjam'];
	$q=mysql_query("SELECT*from t_angsur where kode_pinjam='$kode_pinjam' AND kode_anggota='$kode' order by kode_angsur desc");
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-dolly-flatbed"></i> Data Transaksi</h1>

	<div>
		<a href="laporan/print_angsuran.php?kode_pinjam=<?php echo $kode_pinjam;?>&kode_anggota=<?php echo $kode; ?>" class="btn btn-primary"> <i class="fa fa-print"></i> Cetak Data </a>
		<a href="?pilih=datatransaksi&aksi=pinjamangsur&kode_anggota=<?php echo $kode; ?>" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
			<span class="text">Kembali</span>
		</a>
	</div>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success"><i class="fas fa-fw fa-table"></i> Daftar Riwayat Angsuran <?php $angg=mysql_fetch_array(mysql_query("SELECT nama_anggota from t_anggota where kode_anggota='$kode'")); echo $angg['nama_anggota'];?></h6>
    </div>

    <div class="card-body">
        <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Kode Angsuran</th>
						<th>Kode Pinjam</th>
						<th>Tanggal Angsuran</th>
						<th>Angsuran Ke</th>
						<th>Besar Angsuran</th>
						<th>Denda</th>
					</tr>
				</thead>
				<tbody>
				<?php
				$no=1;
				while($ang=mysql_fetch_array($q)){
				?>
					<tr align="center">
						<td><?php echo $no;?></td>
						<td><?php echo $ang['kode_angsur'];?></td>
						<td><?php echo $l=$ang['kode_pinjam'];?></td>
						<td><?php echo $ang['tgl_entri'];?></td>
						<td><?php echo $ang['angsuran_ke'];?></td>
						<td>Rp. <?php echo Rp($ang['besar_angsuran']);?></td>
						<td>Rp. <?php echo Rp($ang['denda']);?></td>
					</tr>
				<?php
				$no++;}
				?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php
}
?>