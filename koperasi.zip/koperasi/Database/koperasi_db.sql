-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 12 Agu 2022 pada 13.04
-- Versi Server: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `koperasi_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `plafon_bumdes`
--

CREATE TABLE IF NOT EXISTS `plafon_bumdes` (
  `kode_plafon` char(5) NOT NULL,
  `jenis_pinjaman` varchar(10) NOT NULL,
  `pokok` varchar(20) NOT NULL,
  `jasa_bln` varchar(5) NOT NULL,
  `tenor` varchar(4) NOT NULL,
  `jasa_thn` varchar(5) NOT NULL,
  `pokok_bln` varchar(20) NOT NULL,
  `jasa` varchar(20) NOT NULL,
  `angsuran` varchar(20) NOT NULL,
  `pembulatan` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `plafon_bumdes`
--

INSERT INTO `plafon_bumdes` (`kode_plafon`, `jenis_pinjaman`, `pokok`, `jasa_bln`, `tenor`, `jasa_thn`, `pokok_bln`, `jasa`, `angsuran`, `pembulatan`) VALUES
('P001', 'Plafon 1', 'Rp1.000.000', '1,5%', '12', '18%', 'Rp83.333', 'Rp15.000', 'Rp98,333 ', 'Rp99,000'),
('P002', 'Plafon 2', 'Rp2,000,000', '1.5%', '12', '18%', 'Rp166,667', ' Rp30,000 ', ' Rp196,667 ', 'Rp197,000'),
('P003', 'Plafon 3', 'Rp3,000,000', '1.5%', '12', '18%', 'Rp250,000', ' Rp45,000 ', ' Rp295,000 ', ' Rp295,000 '),
('P004', 'Plafon 4', 'Rp4,000,000', '1.5%', '12', '18%', 'Rp333,333', 'Rp60,000 ', 'Rp393,333 ', 'Rp394,000'),
('P005', 'Plafon 5', 'Rp5,000,000', '1.5%', '12', '18%', 'Rp416,667', ' Rp75,000 ', ' Rp491,667 ', 'Rp492,000'),
('P006', 'Plafon 6', 'Rp6,000,000', '1.5%', '12', '18%', 'Rp500,000', ' Rp90,000 ', ' Rp590,000 ', 'Rp590,000'),
('P007', 'Plafon 7', 'Rp7,000,000', '1.5%', '12', '18%', 'Rp583,333', ' Rp105,000 ', ' Rp688,333 ', 'Rp689,000'),
('P008', 'Plafon 8', 'Rp8,000,000', '1.5%', '12', '18%', 'Rp666,667', 'Rp120,000 ', ' Rp786,667 ', 'Rp787,000'),
('P009', 'Plafon 9', 'Rp9,000,000', '1.5%', '12', '18%', 'Rp750,000', ' Rp135,000 ', ' Rp885,000 ', 'Rp885,000'),
('P010', 'Plafon 10', 'Rp10,000,000', '1.5%', '12', '18%', 'Rp833,333', ' Rp150,000 ', ' Rp983,333 ', 'Rp984,000'),
('P011', 'Plafon 11', 'Rp11,000,000', '1.5%', '12', '18%', 'Rp916,667', ' Rp165,000 ', ' Rp1,081,667 ', 'Rp1,082,000'),
('P012', 'Plafon 12', 'Rp12,000,000', '1.5%', '12', '18%', 'Rp1,000,000', ' Rp180,000 ', ' Rp1,180,000 ', 'Rp1,180,000'),
('P013', 'Plafon 13', 'Rp13,000,000', '1.5%', '12', '18%', 'Rp1,083,333', ' Rp195,000 ', ' Rp1,278,333 ', 'Rp1,279,000'),
('P014', 'Plafon 14', 'Rp14,000,000', '1.5%', '12', '18%', 'Rp1,166,667', ' Rp210,000 ', ' Rp1,376,667 ', 'Rp1,377,000'),
('P015', 'Plafon 15', 'Rp15,000,000', '1.5%', '12', '18%', 'Rp1,250,000', ' Rp225,000 ', ' Rp1,475,000 ', 'Rp1,475,000'),
('P016', 'Plafon 16', 'Rp25,000,000', '1.5%', '12', '18%', 'Rp2,083,333', ' Rp375,000 ', ' Rp2,458,333 ', 'Rp2,459,000'),
('P101', 'Plafon 17', 'Rp1,000,000', '1.5%', '24', '36%', 'Rp41,667', ' Rp15,000 ', ' Rp56,667 ', 'Rp57,000'),
('P102', 'Plafon 18', 'Rp2,000,000', '1.5%', '24', '36%', 'Rp83,333', ' Rp30,000 ', ' Rp113,333 ', 'Rp114,000'),
('P103', 'Plafon 19', 'Rp3,000,000', '1.5%', '24', '36%', 'Rp125,000', ' Rp45,000 ', ' Rp170,000 ', 'Rp170,000'),
('P104', 'Plafon 20', 'Rp4,000,000', '1.5%', '24', '36%', 'Rp166,667', ' Rp60,000 ', ' Rp226,667 ', 'Rp227,000'),
('P105', 'Plafon 21', 'Rp5,000,000', '1.5%', '24', '36%', 'Rp208,333', ' Rp75,000 ', ' Rp283,333 ', 'Rp284,000'),
('P106', 'Plafon 22', 'Rp6,000,000', '1.5%', '24', '36%', 'Rp250,000', ' Rp90,000 ', ' Rp340,000 ', 'Rp340,000'),
('P107', 'Plafon 23', 'Rp7,000,000', '1.5%', '24', '36%', 'Rp291,667', ' Rp105,000 ', ' Rp396,667 ', 'Rp397,000'),
('P108', 'Plafon 24', 'Rp8,000,000', '1.5%', '24', '36%', 'Rp333,333', ' Rp120,000 ', ' Rp453,333 ', 'Rp454,000'),
('P109', 'Plafon 25', 'Rp9,000,000', '1.5%', '24', '36%', 'Rp375,000', ' Rp135,000 ', ' Rp510,000 ', ' Rp510,000 '),
('P110', 'Plafon 26', 'Rp10,000,000', '1.5%', '24', '36%', 'Rp416,667', ' Rp150,000 ', ' Rp566,667 ', 'Rp567,000'),
('P111', 'Plafon 27', 'Rp11,000,000', '1.5%', '24', '36%', 'Rp458,333', ' Rp165,000 ', ' Rp623,333 ', 'Rp624,000'),
('P112', 'Plafon 28', 'Rp12,000,000', '1.5%', '24', '36%', 'Rp500,000', ' Rp180,000 ', 'Rp680,000', 'Rp680,000'),
('P113', 'Plafon 29', 'Rp13,000,000', '1.5%', '24', '36%', 'Rp541,667', ' Rp195,000 ', ' Rp736,667 ', 'Rp737,000'),
('P114', 'Plafon 30', 'Rp14,000,000', '1.5%', '24', '36%', 'Rp583,333', ' Rp210,000 ', ' Rp793,333 ', 'Rp794,000'),
('P115', 'Plafon 31', 'Rp15,000,000', '1.5%', '24', '36%', 'Rp625,000', ' Rp225,000 ', ' Rp850,000 ', ' Rp850,000 '),
('P116', 'Plafon 32', 'Rp25,000,000', '1.5%', '24', '36%', 'Rp1,041,667', ' Rp375,000 ', ' Rp1,416,667 ', 'Rp1,417,000'),
('P201', 'Plafon 33', 'Rp1,000,000', '1.5%', '36', '54%', 'Rp27,778', ' Rp15,000 ', ' Rp42,778 ', 'Rp43,000'),
('P202', 'Plafon 34', 'Rp2,000,000', '1.5%', '36', '54%', 'Rp55,556', ' Rp30,000 ', ' Rp85,556 ', 'Rp86,000'),
('P203', 'Plafon 35', 'Rp3,000,000', '1.5%', '36', '54%', 'Rp83,333', ' Rp45,000 ', ' Rp128,333 ', 'Rp129,000'),
('P204', 'Plafon 36', 'Rp4,000,000', '1.5%', '36', '54%', 'Rp111,111', ' Rp60,000 ', ' Rp171,111 ', 'Rp172,000'),
('P205', 'Plafon 37', 'Rp5,000,000', '1.5%', '36', '54%', 'Rp138,889', ' Rp75,000 ', ' Rp213,889 ', 'Rp214,000'),
('P206', 'Plafon 38', 'Rp6,000,000', '1.5%', '36', '54%', 'Rp166,667', ' Rp90,000 ', ' Rp256,667 ', 'Rp257,000'),
('P207', 'Plafon 39', 'Rp7,000,000', '1.5%', '36', '54%', 'Rp194,444', ' Rp105,000 ', ' Rp299,444 ', 'Rp300,000'),
('P208', 'Plafon 40', 'Rp8,000,000', '1.5%', '36', '54%', 'Rp222,222', ' Rp120,000 ', ' Rp342,222 ', 'Rp343,000'),
('P209', 'Plafon 41', 'Rp9,000,000', '1.5%', '36', '54%', 'Rp250,000', ' Rp135,000 ', ' Rp385,000 ', 'Rp385,000'),
('P210', 'Plafon 42', 'Rp10,000,000', '1.5%', '36', '54%', 'Rp277,778', ' Rp150,000 ', ' Rp427,778 ', 'Rp428,000'),
('P211', 'Plafon 43', 'Rp11,000,000', '1.5%', '36', '54%', 'Rp305,556', ' Rp165,000 ', ' Rp470,556 ', 'Rp471,000'),
('P212', 'Plafon 44', 'Rp12,000,000', '1.5%', '36', '54%', 'Rp333,333', ' Rp180,000 ', ' Rp513,333 ', 'Rp514,000'),
('P213', 'Plafon 45', 'Rp13,000,000', '1.5%', '36', '54%', 'Rp361,111', ' Rp195,000 ', ' Rp556,111 ', 'Rp557,000'),
('P214', 'Plafon 46', 'Rp14,000,000', '1.5%', '36', '54%', 'Rp388,889', ' Rp210,000 ', ' Rp598,889 ', 'Rp599,000'),
('P215', 'Plafon 47', 'Rp15,000,000', '1.5%', '36', '54%', 'Rp416,667', ' Rp225,000 ', ' Rp641,667 ', 'Rp642,000'),
('P216', 'Plafon 48', 'Rp25,000,000', '1.5%', '36', '54%', 'Rp694,444', ' Rp375,000 ', ' Rp1,069,444 ', 'Rp1,070,000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_anggota`
--

CREATE TABLE IF NOT EXISTS `t_anggota` (
  `kode_anggota` char(16) NOT NULL,
  `kode_tabungan` int(11) NOT NULL,
  `nama_anggota` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `alamat_anggota` varchar(100) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `tgl_masuk` date NOT NULL,
  `telp` varchar(12) NOT NULL,
  `tempat_lahir` varchar(20) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `status` varchar(10) NOT NULL,
  `u_entry` varchar(50) NOT NULL,
  `tgl_entri` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `t_anggota`
--

INSERT INTO `t_anggota` (`kode_anggota`, `kode_tabungan`, `nama_anggota`, `password`, `alamat_anggota`, `jenis_kelamin`, `pekerjaan`, `tgl_masuk`, `telp`, `tempat_lahir`, `tgl_lahir`, `status`, `u_entry`, `tgl_entri`) VALUES
('3517011608900001', 69, 'Herlina', 'n', 'Dusun Ngaren Desa Plosogenuk', 'Perempuan', 'Wiraswasta', '2022-07-15', '089657690754', 'Jombang', '1990-08-16', 'keluar', 'Petugas', '2022-07-15'),
('3517010207910003', 64, 'Yuliana', 'n', 'Dusun Ploso Desa Plosogenuk', 'Perempuan', 'Pegawai', '2022-07-11', '082177850099', 'Jombang', '1991-07-02', 'keluar', 'Petugas', '2022-07-12'),
('3517010207500002', 65, 'Magdalena', 'n', 'Dusun Ploso Desa Plosogenuk', 'Perempuan', 'Petani', '2022-07-15', '-', 'Jombang', '1950-07-02', 'aktif', 'Petugas', '2022-07-15'),
('3517010811780001', 66, 'Saiful Anam', 'n', 'Dusun Ploso Desa Plosogenuk', 'Laki-laki', 'Petani', '2022-07-15', '081276882901', 'Jombang', '1978-11-08', 'aktif', 'Petugas', '2022-07-15'),
('3517012106900001', 67, 'Hadi Wibowo', 'n', 'Dusun Ngaren Plosogenuk', 'Laki-laki', 'Pedagang', '2022-07-15', '085775612209', 'Jombang', '1990-06-21', 'aktif', 'Petugas', '2022-07-15'),
('3517010406730005', 68, 'Samiaji', 'n', 'Dusun Ploso Desa Plosogenuk', 'Laki-laki', 'Wiraswasta', '2022-07-15', '085899077125', 'Jombang', '1973-06-04', 'aktif', 'Petugas', '2022-07-15'),
('3517012104820002', 63, 'Matdori', 'n', 'Dusun Ngaren Desa Plosogenuk', 'Laki-laki', 'Wiraswasta', '2022-07-11', '089677812301', 'Jombang', '1982-04-21', 'aktif', 'Petugas', '2022-07-11');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_angsur`
--

CREATE TABLE IF NOT EXISTS `t_angsur` (
`kode_angsur` int(11) NOT NULL,
  `kode_pinjam` int(11) NOT NULL,
  `angsuran_ke` int(11) NOT NULL,
  `besar_angsuran` int(11) NOT NULL,
  `denda` int(11) NOT NULL,
  `sisa_pinjam` int(11) NOT NULL,
  `kode_anggota` char(16) NOT NULL,
  `u_entry` varchar(50) NOT NULL,
  `tgl_entri` date NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=437 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `t_angsur`
--

INSERT INTO `t_angsur` (`kode_angsur`, `kode_pinjam`, `angsuran_ke`, `besar_angsuran`, `denda`, `sisa_pinjam`, `kode_anggota`, `u_entry`, `tgl_entri`) VALUES
(433, 100, 4, 98333, 0, 106667, '3517012106900001', '', '0000-00-00'),
(432, 100, 3, 98333, 0, 205000, '3517012106900001', '', '0000-00-00'),
(430, 100, 1, 98333, 0, 401667, '3517012106900001', '', '0000-00-00'),
(431, 100, 2, 98333, 0, 303333, '3517012106900001', '', '0000-00-00'),
(429, 99, 24, 170000, 0, -1080000, '3517010811780001', '', '0000-00-00'),
(427, 99, 22, 170000, 0, -740000, '3517010811780001', '', '0000-00-00'),
(428, 99, 23, 170000, 0, -910000, '3517010811780001', '', '0000-00-00'),
(426, 99, 21, 170000, 0, -570000, '3517010811780001', '', '0000-00-00'),
(424, 99, 19, 170000, 0, -230000, '3517010811780001', '', '0000-00-00'),
(425, 99, 20, 170000, 0, -400000, '3517010811780001', '', '0000-00-00'),
(423, 99, 18, 170000, 0, -60000, '3517010811780001', '', '0000-00-00'),
(421, 99, 16, 170000, 0, 280000, '3517010811780001', '', '0000-00-00'),
(422, 99, 17, 170000, 0, 110000, '3517010811780001', '', '0000-00-00'),
(420, 99, 15, 170000, 0, 450000, '3517010811780001', '', '0000-00-00'),
(418, 99, 13, 170000, 0, 790000, '3517010811780001', '', '0000-00-00'),
(419, 99, 14, 170000, 0, 620000, '3517010811780001', '', '0000-00-00'),
(417, 99, 12, 170000, 0, 960000, '3517010811780001', '', '0000-00-00'),
(415, 99, 10, 170000, 0, 1300000, '3517010811780001', '', '0000-00-00'),
(416, 99, 11, 170000, 0, 1130000, '3517010811780001', '', '0000-00-00'),
(414, 99, 9, 170000, 0, 1470000, '3517010811780001', '', '0000-00-00'),
(413, 99, 8, 170000, 0, 1640000, '3517010811780001', '', '0000-00-00'),
(412, 99, 7, 170000, 0, 1810000, '3517010811780001', '', '0000-00-00'),
(411, 99, 6, 170000, 0, 1980000, '3517010811780001', '', '0000-00-00'),
(410, 99, 5, 170000, 0, 2150000, '3517010811780001', '', '0000-00-00'),
(409, 99, 4, 170000, 0, 2320000, '3517010811780001', '', '0000-00-00'),
(408, 99, 3, 170000, 0, 2490000, '3517010811780001', '', '0000-00-00'),
(407, 99, 2, 170000, 0, 2660000, '3517010811780001', '', '0000-00-00'),
(406, 99, 1, 170000, 0, 2830000, '3517010811780001', '', '0000-00-00'),
(405, 98, 18, 211667, 0, -810000, '3517010406730005', '', '0000-00-00'),
(404, 98, 17, 211667, 0, -598333, '3517010406730005', '', '0000-00-00'),
(403, 98, 16, 211667, 0, -386667, '3517010406730005', '', '0000-00-00'),
(402, 98, 15, 211667, 0, -175000, '3517010406730005', '', '0000-00-00'),
(401, 98, 14, 211667, 0, 36667, '3517010406730005', '', '0000-00-00'),
(400, 98, 13, 211667, 0, 248333, '3517010406730005', '', '0000-00-00'),
(399, 98, 12, 211667, 0, 460000, '3517010406730005', '', '0000-00-00'),
(398, 98, 11, 211667, 0, 671667, '3517010406730005', '', '0000-00-00'),
(397, 98, 10, 211667, 0, 883333, '3517010406730005', '', '0000-00-00'),
(396, 98, 9, 211667, 0, 1095000, '3517010406730005', '', '0000-00-00'),
(395, 98, 8, 211667, 0, 1306667, '3517010406730005', '', '0000-00-00'),
(394, 98, 7, 211667, 0, 1518333, '3517010406730005', '', '0000-00-00'),
(393, 98, 6, 211667, 0, 1730000, '3517010406730005', '', '0000-00-00'),
(392, 98, 5, 211667, 0, 1941667, '3517010406730005', '', '0000-00-00'),
(391, 98, 4, 211667, 0, 2153333, '3517010406730005', '', '0000-00-00'),
(390, 98, 3, 211667, 0, 2365000, '3517010406730005', '', '0000-00-00'),
(389, 98, 2, 211667, 0, 2576667, '3517010406730005', '', '0000-00-00'),
(388, 98, 1, 211667, 0, 2788333, '3517010406730005', '', '0000-00-00'),
(387, 97, 36, 171111, 0, -2160000, '3517010207500002', '', '0000-00-00'),
(386, 97, 35, 171111, 0, -1988889, '3517010207500002', '', '0000-00-00'),
(385, 97, 34, 171111, 0, -1817778, '3517010207500002', '', '0000-00-00'),
(384, 97, 33, 171111, 0, -1646667, '3517010207500002', '', '0000-00-00'),
(383, 97, 32, 171111, 0, -1475556, '3517010207500002', '', '0000-00-00'),
(382, 97, 31, 171111, 0, -1304444, '3517010207500002', '', '0000-00-00'),
(381, 97, 30, 171111, 0, -1133333, '3517010207500002', '', '0000-00-00'),
(380, 97, 29, 171111, 0, -962222, '3517010207500002', '', '0000-00-00'),
(379, 97, 28, 171111, 0, -791111, '3517010207500002', '', '0000-00-00'),
(378, 97, 27, 171111, 0, -620000, '3517010207500002', '', '0000-00-00'),
(377, 97, 26, 171111, 0, -448889, '3517010207500002', '', '0000-00-00'),
(376, 97, 25, 171111, 0, -277778, '3517010207500002', '', '0000-00-00'),
(375, 97, 24, 171111, 0, -106667, '3517010207500002', '', '0000-00-00'),
(374, 97, 23, 171111, 0, 64444, '3517010207500002', '', '0000-00-00'),
(373, 97, 22, 171111, 0, 235556, '3517010207500002', '', '0000-00-00'),
(372, 97, 21, 171111, 0, 406667, '3517010207500002', '', '0000-00-00'),
(371, 97, 20, 171111, 0, 577778, '3517010207500002', '', '0000-00-00'),
(370, 97, 19, 171111, 0, 748889, '3517010207500002', 'Petugas', '2022-07-15'),
(369, 97, 18, 171111, 0, 920000, '3517010207500002', 'Petugas', '2022-07-15'),
(368, 97, 17, 171111, 0, 1091111, '3517010207500002', 'Petugas', '2022-07-15'),
(367, 97, 16, 171111, 0, 1262222, '3517010207500002', 'Petugas', '2022-07-15'),
(366, 97, 15, 171111, 0, 1433333, '3517010207500002', 'Petugas', '2022-07-15'),
(365, 97, 14, 171111, 0, 1604444, '3517010207500002', 'Petugas', '2022-07-15'),
(364, 97, 13, 171111, 0, 1775556, '3517010207500002', 'Petugas', '2022-07-15'),
(363, 97, 12, 171111, 0, 1946667, '3517010207500002', 'Petugas', '2022-07-15'),
(362, 97, 11, 171111, 0, 2117778, '3517010207500002', 'Petugas', '2022-07-15'),
(361, 97, 10, 171111, 0, 2288889, '3517010207500002', 'Petugas', '2022-07-15'),
(360, 97, 9, 171111, 0, 2460000, '3517010207500002', 'Petugas', '2022-07-15'),
(359, 97, 8, 171111, 0, 2631111, '3517010207500002', 'Petugas', '2022-07-15'),
(358, 97, 7, 171111, 0, 2802222, '3517010207500002', 'Petugas', '2022-07-15'),
(357, 97, 6, 171111, 0, 2973333, '3517010207500002', 'Petugas', '2022-07-15'),
(356, 97, 5, 171111, 0, 3144444, '3517010207500002', 'Petugas', '2022-07-15'),
(355, 97, 4, 171111, 0, 3315556, '3517010207500002', 'Petugas', '2022-07-15'),
(354, 97, 3, 171111, 0, 3486667, '3517010207500002', 'Petugas', '2022-07-15'),
(353, 97, 2, 171111, 0, 3657778, '3517010207500002', 'Petugas', '2022-07-15'),
(352, 97, 1, 171111, 0, 3828889, '3517010207500002', 'Petugas', '2022-07-15'),
(351, 96, 18, 211667, 0, -810000, '3517012104820002', 'Petugas', '2022-07-12'),
(350, 96, 17, 211667, 0, -598333, '3517012104820002', 'Petugas', '2022-07-12'),
(349, 96, 16, 211667, 0, -386667, '3517012104820002', 'Petugas', '2022-07-12'),
(348, 96, 15, 211667, 0, -175000, '3517012104820002', 'Petugas', '2022-07-12'),
(347, 96, 14, 211667, 0, 36667, '3517012104820002', 'Petugas', '2022-07-12'),
(346, 96, 13, 211667, 0, 248333, '3517012104820002', 'Petugas', '2022-07-12'),
(345, 96, 12, 211667, 0, 460000, '3517012104820002', 'Petugas', '2022-07-12'),
(344, 96, 11, 211667, 0, 671667, '3517012104820002', 'Petugas', '2022-07-12'),
(343, 96, 10, 211667, 0, 883333, '3517012104820002', 'Petugas', '2022-07-12'),
(342, 96, 9, 211667, 0, 1095000, '3517012104820002', 'Petugas', '2022-07-12'),
(341, 96, 8, 211667, 0, 1306667, '3517012104820002', 'Petugas', '2022-07-12'),
(340, 96, 7, 211667, 0, 1518333, '3517012104820002', 'Petugas', '2022-07-12'),
(339, 96, 6, 211667, 0, 1730000, '3517012104820002', 'Petugas', '2022-07-12'),
(338, 96, 5, 211667, 0, 1941667, '3517012104820002', 'Petugas', '2022-07-12'),
(337, 96, 4, 211667, 0, 2153333, '3517012104820002', 'Petugas', '2022-07-12'),
(336, 96, 3, 211667, 0, 2365000, '3517012104820002', 'Petugas', '2022-07-12'),
(334, 96, 1, 211667, 0, 2788333, '3517012104820002', 'Petugas', '2022-07-12'),
(335, 96, 2, 211667, 0, 2576667, '3517012104820002', 'Petugas', '2022-07-12'),
(434, 100, 5, 98333, 0, 8333, '3517012106900001', '', '0000-00-00'),
(435, 100, 6, 98333, 0, -90000, '3517012106900001', '', '0000-00-00'),
(436, 101, 1, 49167, 0, 450833, '3517010207500002', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_jenis_pinjam`
--

CREATE TABLE IF NOT EXISTS `t_jenis_pinjam` (
  `kode_jenis_pinjam` char(5) NOT NULL,
  `nama_pinjaman` varchar(50) NOT NULL,
  `lama_angsuran` int(11) NOT NULL,
  `maks_pinjam` double NOT NULL,
  `bunga` float NOT NULL,
  `u_entry` varchar(50) NOT NULL,
  `tgl_entri` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `t_jenis_pinjam`
--

INSERT INTO `t_jenis_pinjam` (`kode_jenis_pinjam`, `nama_pinjaman`, `lama_angsuran`, `maks_pinjam`, `bunga`, `u_entry`, `tgl_entri`) VALUES
('P0001', 'Pinjaman Plafon ke 1', 12, 25000000, 1.5, '', '2022-06-09'),
('P0002', 'Pinjaman Plafon ke 2', 24, 25000000, 1.5, '', '2022-06-09'),
('P0003', 'Pinjaman Plafon ke 3', 36, 25000000, 1.5, '', '2022-06-09'),
('P0004', 'Pinjaman Plafon ke 4', 6, 25000000, 3, '', '2022-06-09'),
('P0005', 'Plafon Pinjaman ke 5', 18, 25000000, 1.5, '', '2022-06-09');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_jenis_simpan`
--

CREATE TABLE IF NOT EXISTS `t_jenis_simpan` (
  `kode_jenis_simpan` char(5) NOT NULL,
  `nama_simpanan` varchar(50) NOT NULL,
  `besar_simpanan` float NOT NULL,
  `u_entry` varchar(50) NOT NULL,
  `tgl_entri` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `t_jenis_simpan`
--

INSERT INTO `t_jenis_simpan` (`kode_jenis_simpan`, `nama_simpanan`, `besar_simpanan`, `u_entry`, `tgl_entri`) VALUES
('S0006', 'sukarela', 0, 'Petugas', '2022-05-23'),
('S0005', 'wajib', 25000, 'Petugas', '2022-05-23'),
('S0004', 'pokok', 10000, 'Petugas', '2022-05-23');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_pengajuan`
--

CREATE TABLE IF NOT EXISTS `t_pengajuan` (
`kode_pengajuan` int(4) NOT NULL,
  `tgl_pengajuan` date NOT NULL,
  `kode_anggota` char(16) NOT NULL,
  `kode_jenis_pinjam` char(5) NOT NULL,
  `besar_pinjam` varchar(10) NOT NULL,
  `tgl_acc` date NOT NULL,
  `status` varchar(12) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `t_pengajuan`
--

INSERT INTO `t_pengajuan` (`kode_pengajuan`, `tgl_pengajuan`, `kode_anggota`, `kode_jenis_pinjam`, `besar_pinjam`, `tgl_acc`, `status`) VALUES
(1, '2022-07-12', '3517012104820002', 'P0005', '3000000', '2022-07-12', 'diterima'),
(2, '2022-07-15', '3517010207500002', 'P0003', '4000000', '2022-07-15', 'diterima'),
(3, '2022-07-15', '3517010406730005', 'P0005', '3000000', '2022-07-15', 'diterima'),
(4, '2022-07-15', '3517010811780001', 'P0002', '3000000', '2022-07-15', 'diterima'),
(5, '2022-07-15', '3517012106900001', 'P0004', '500000', '2022-07-15', 'diterima'),
(6, '2022-07-16', '3517010207500002', 'P0001', '500000', '2022-07-16', 'diterima');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_pengambilan`
--

CREATE TABLE IF NOT EXISTS `t_pengambilan` (
`kode_ambil` int(5) NOT NULL,
  `kode_anggota` char(16) NOT NULL,
  `kode_tabungan` int(5) NOT NULL,
  `besar_ambil` int(20) NOT NULL,
  `tgl_ambil` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `t_pengambilan`
--

INSERT INTO `t_pengambilan` (`kode_ambil`, `kode_anggota`, `kode_tabungan`, `besar_ambil`, `tgl_ambil`) VALUES
(7, '3517010207910003', 0, 10000, '2022-07-12'),
(8, '3517011608900001', 0, 10000, '2022-07-15'),
(9, '3517102008990001', 70, 10000, '2022-08-03');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_pinjam`
--

CREATE TABLE IF NOT EXISTS `t_pinjam` (
`kode_pinjam` int(11) NOT NULL,
  `kode_anggota` char(16) NOT NULL,
  `kode_jenis_pinjam` char(5) NOT NULL,
  `besar_pinjam` double NOT NULL,
  `besar_angsuran` double NOT NULL,
  `lama_angsuran` int(11) NOT NULL,
  `sisa_angsuran` int(11) NOT NULL,
  `sisa_pinjaman` double NOT NULL,
  `u_entry` varchar(50) NOT NULL,
  `tgl_entri` date NOT NULL,
  `tgl_tempo` date NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=102 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `t_pinjam`
--

INSERT INTO `t_pinjam` (`kode_pinjam`, `kode_anggota`, `kode_jenis_pinjam`, `besar_pinjam`, `besar_angsuran`, `lama_angsuran`, `sisa_angsuran`, `sisa_pinjaman`, `u_entry`, `tgl_entri`, `tgl_tempo`, `status`) VALUES
(101, '3517010207500002', 'P0001', 500000, 49166.666666667, 12, 1, 450833.33333333, '', '2022-07-16', '2022-09-14', 'belum lunas'),
(100, '3517012106900001', 'P0004', 500000, 98333.333333333, 6, 6, -89999.999999986, '', '2022-07-15', '2023-01-11', 'lunas'),
(99, '3517010811780001', 'P0002', 3000000, 170000, 24, 24, -1080000, '', '2022-07-15', '2024-07-04', 'lunas'),
(97, '3517010207500002', 'P0003', 4000000, 171111.11111111, 36, 36, -2159999.9999997, '', '2022-07-15', '2025-06-29', 'lunas'),
(98, '3517010406730005', 'P0005', 3000000, 211666.66666667, 18, 18, -810000.00000033, '', '2022-07-15', '2024-01-06', 'lunas'),
(96, '3517012104820002', 'P0005', 3000000, 211666.66666667, 18, 18, -810000.00000033, '', '2022-07-12', '2024-01-03', 'lunas');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_simpan`
--

CREATE TABLE IF NOT EXISTS `t_simpan` (
`kode_simpan` int(11) NOT NULL,
  `jenis_simpan` varchar(10) NOT NULL,
  `besar_simpanan` double NOT NULL,
  `kode_anggota` char(16) NOT NULL,
  `u_entry` varchar(50) NOT NULL,
  `tgl_mulai` date NOT NULL,
  `tgl_entri` date NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=208 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `t_simpan`
--

INSERT INTO `t_simpan` (`kode_simpan`, `jenis_simpan`, `besar_simpanan`, `kode_anggota`, `u_entry`, `tgl_mulai`, `tgl_entri`) VALUES
(201, 'pokok', 10000, '3517102008990001', '', '0000-00-00', '0000-00-00'),
(199, 'pokok', 10000, '3517010406730005', 'Petugas', '2022-07-15', '2022-07-15'),
(198, 'pokok', 10000, '3517012106900001', 'Petugas', '2022-07-15', '2022-07-15'),
(197, 'pokok', 10000, '3517010811780001', 'Petugas', '2022-07-15', '2022-07-15'),
(196, 'pokok', 10000, '3517010207500002', 'Petugas', '2022-07-15', '2022-07-15'),
(194, 'pokok', 10000, '3517012104820002', 'Petugas', '2022-07-11', '2022-07-11'),
(206, 'wajib', 25000, '3517010406730005', 'Petugas', '2022-07-26', '2022-07-19'),
(207, 'wajib', 25000, '3517010207500002', 'Petugas', '2022-07-26', '2022-07-19');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_tabungan`
--

CREATE TABLE IF NOT EXISTS `t_tabungan` (
`kode_tabungan` int(11) NOT NULL,
  `kode_anggota` char(16) COLLATE latin1_general_ci NOT NULL,
  `tgl_mulai` date NOT NULL,
  `besar_tabungan` double NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=71 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `t_tabungan`
--

INSERT INTO `t_tabungan` (`kode_tabungan`, `kode_anggota`, `tgl_mulai`, `besar_tabungan`) VALUES
(70, '3517102008990001', '0000-00-00', 0),
(68, '3517010406730005', '2022-07-15', 60000),
(67, '3517012106900001', '2022-07-15', 10000),
(66, '3517010811780001', '2022-07-15', 10000),
(65, '3517010207500002', '2022-07-15', 120000),
(63, '3517012104820002', '2022-07-11', 10000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_user`
--

CREATE TABLE IF NOT EXISTS `t_user` (
  `kode_user` int(16) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `tgl_entri` date NOT NULL,
  `level` char(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `t_user`
--

INSERT INTO `t_user` (`kode_user`, `username`, `password`, `nama`, `tgl_entri`, `level`) VALUES
(1, 'petugas', 'petugas', 'Petugas', '2021-04-01', 'admin'),
(2, 'direktur', 'direktur', 'Direktur', '2021-04-01', 'operator');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `plafon_bumdes`
--
ALTER TABLE `plafon_bumdes`
 ADD PRIMARY KEY (`kode_plafon`);

--
-- Indexes for table `t_anggota`
--
ALTER TABLE `t_anggota`
 ADD PRIMARY KEY (`kode_anggota`);

--
-- Indexes for table `t_angsur`
--
ALTER TABLE `t_angsur`
 ADD PRIMARY KEY (`kode_angsur`);

--
-- Indexes for table `t_jenis_pinjam`
--
ALTER TABLE `t_jenis_pinjam`
 ADD PRIMARY KEY (`kode_jenis_pinjam`);

--
-- Indexes for table `t_jenis_simpan`
--
ALTER TABLE `t_jenis_simpan`
 ADD PRIMARY KEY (`kode_jenis_simpan`);

--
-- Indexes for table `t_pengajuan`
--
ALTER TABLE `t_pengajuan`
 ADD PRIMARY KEY (`kode_pengajuan`);

--
-- Indexes for table `t_pengambilan`
--
ALTER TABLE `t_pengambilan`
 ADD PRIMARY KEY (`kode_ambil`);

--
-- Indexes for table `t_pinjam`
--
ALTER TABLE `t_pinjam`
 ADD PRIMARY KEY (`kode_pinjam`);

--
-- Indexes for table `t_simpan`
--
ALTER TABLE `t_simpan`
 ADD PRIMARY KEY (`kode_simpan`);

--
-- Indexes for table `t_tabungan`
--
ALTER TABLE `t_tabungan`
 ADD PRIMARY KEY (`kode_tabungan`);

--
-- Indexes for table `t_user`
--
ALTER TABLE `t_user`
 ADD PRIMARY KEY (`kode_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `t_anggota`
--
ALTER TABLE `t_anggota`
AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `t_angsur`
--
ALTER TABLE `t_angsur`
MODIFY `kode_angsur` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=437;
--
-- AUTO_INCREMENT for table `t_pengajuan`
--
ALTER TABLE `t_pengajuan`
MODIFY `kode_pengajuan` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `t_pengambilan`
--
ALTER TABLE `t_pengambilan`
MODIFY `kode_ambil` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `t_pinjam`
--
ALTER TABLE `t_pinjam`
MODIFY `kode_pinjam` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=102;
--
-- AUTO_INCREMENT for table `t_simpan`
--
ALTER TABLE `t_simpan`
MODIFY `kode_simpan` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=208;
--
-- AUTO_INCREMENT for table `t_tabungan`
--
ALTER TABLE `t_tabungan`
MODIFY `kode_tabungan` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=71;
--
-- AUTO_INCREMENT for table `t_user`
--
ALTER TABLE `t_user`
AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
