<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>KOPSINJAM Karya Mulur</title>

  <!-- Custom fonts for this template-->
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="assets/css/sb-admin-2.min.css" rel="stylesheet">
  
  <!-- Custom styles for this page -->
  <link href="assets/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-success sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="?pilih=home">
        <div class="sidebar-brand-icon">
          <img src="assets/img/logo.png" width="110px" height="65px" >
        </div>
        <div class="sidebar-brand-text mx-3">KOPSINJAM</div>
      </a>

	  <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item <?php $p = $_GET['pilih']; if($p=='home'){echo "active";} ?>">
        <a class="nav-link" href="?pilih=home">
          <i class="fas fa-fw fa-home"></i>
          <span>Dashboard</span></a>
      </li>
	
	<?php 
	if($_SESSION['level']=='admin')
	{
	?>
	
	  <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        MASTER DATA
      </div>
	  
	  
	  <li class="nav-item <?php $p = $_GET['pilih']; if(($p=='dataanggota')){echo "active";} ?>">
        <a class="nav-link" href="?pilih=dataanggota">
          <i class="fas fa-fw fa-users"></i>
          <span>Anggota</span></a>
      </li>
	  
	  <li class="nav-item <?php $p = $_GET['pilih']; if(($p=='datatabungan')){echo "active";} ?>">
        <a class="nav-link" href="?pilih=datatabungan">
          <i class="fas fa-fw fa-money-bill-wave"></i>
          <span>Simpanan</span></a>
      </li>
	  
	  <li class="nav-item <?php $p = $_GET['pilih']; if(($p=='datapengajuan')){echo "active";} ?>">
        <a class="nav-link" href="?pilih=datapengajuan&aksi=admin">
          <i class="fas fa-fw fa-location-arrow"></i>
          <span>Pinjaman</span></a>
      </li>
	  
	  <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        MASTER TRANSAKSI
      </div>

	  
	  <li class="nav-item <?php $p = $_GET['pilih']; if(($p=='datatransaksi')){echo "active";} ?>">
        <a class="nav-link" href="?pilih=datatransaksi">
          <i class="fas fa-fw fa-dolly-flatbed"></i>
          <span>Data Transaksi</span></a>
      </li>
	  
	  
	  <!-- Divider -->
      <hr class="sidebar-divider">
	  
	  <!-- Heading -->
      <div class="sidebar-heading">
        MASTER SETTING
      </div>
	  
	  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item <?php $p = $_GET['pilih']; if(($p=='datajenissimpanan')||($p=='datajenispinjaman')){echo "active";} ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages2" aria-expanded="true" aria-controls="collapsePages2">
          <i class="fas fa-fw fa-cogs"></i>
          <span>Data Pengaturan</span>
        </a>
        <div id="collapsePages2" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="?pilih=datajenispinjaman">Jenis Pinjaman</a>
            <a class="collapse-item" href="?pilih=datajenissimpanan">Jenis Simpanan</a>
            <a class="collapse-item" href="?pilih=datajenisplafon">Jenis Plafon BUMDes</a>
          </div>
        </div>
      </li>
	  
	  <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        MASTER USER
      </div>
	  
	  <li class="nav-item <?php $p = $_GET['pilih']; if(($p=='datapengguna')){echo "active";} ?>">
        <a class="nav-link" href="?pilih=datapengguna">
          <i class="fas fa-fw fa-users-cog"></i>
          <span>Data Pengguna</span></a>
      </li>
	  
	  <!-- Divider -->
      <hr class="sidebar-divider">
	  
	  <!-- Heading -->
      <div class="sidebar-heading">
        MASTER LAPORAN
      </div>
	  
	  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item <?php $p = $_GET['pilih']; if(($p=='lapdataanggota')||($p=='lapdatasimpanan')||($p=='lapdatapinjam')||($p=='lapperbulan')){echo "active";} ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages1" aria-expanded="true" aria-controls="collapsePages1">
          <i class="fas fa-fw fa-print"></i>
          <span>Laporan</span>
        </a>
        <div id="collapsePages1" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="?pilih=lapdataanggota">Anggota</a>
            <a class="collapse-item" href="?pilih=lapdatasimpanan">Simpanan</a>
            <a class="collapse-item" href="?pilih=lapdatapinjam&aksi=semua">Pinjaman</a>
			<a class="collapse-item" href="?pilih=lapperbulan">Perbulan</a>
          </div>
        </div>
      </li>
	  
	  
	  
	<?php
	}
	else if($_SESSION['level']=='operator')
	{
	?>
	
	<?php
	}
	?>
      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          
		  <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn text-success d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">
						
			<!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="text-uppercase mr-2 d-none d-lg-inline text-gray-600 small">
					<?php echo $_SESSION['kopname'];?>
				</span>
                <img class="img-profile rounded-circle" src="assets/img/user.png">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
					<i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
					Keluar
				</a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->
		
		<div class="container-fluid">